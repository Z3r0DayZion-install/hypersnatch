export function createPolicyState() {
  return {
    airgapped: false,
    releaseChannel: "stable",
    maxConcurrency: 3,
    profile: "balanced",
    minConfidence: 0.5,
    circuitBreakerThreshold: 5
  };
}

export function setReleaseChannel(policy, channel) {
  const allowed = new Set(["stable", "canary", "nightly"]);
  if (!allowed.has(channel)) throw new Error("Invalid release channel");
  policy.releaseChannel = channel;
  if (channel === "stable") policy.maxConcurrency = 2;
  if (channel === "canary") policy.maxConcurrency = 4;
  if (channel === "nightly") policy.maxConcurrency = 6;
  return policy;
}

export function canUseNetwork(policy) {
  return !policy.airgapped;
}

const PROFILES = {
  strict: {
    minConfidence: 0.8,
    maxConcurrency: 2,
    allowOnlineAdapter: false
  },
  balanced: {
    minConfidence: 0.55,
    maxConcurrency: 4,
    allowOnlineAdapter: true
  },
  aggressive: {
    minConfidence: 0.35,
    maxConcurrency: 8,
    allowOnlineAdapter: true
  }
};

export function setProfile(policy, profileName) {
  const profile = PROFILES[profileName];
  if (!profile) throw new Error("Invalid policy profile");
  policy.profile = profileName;
  policy.minConfidence = profile.minConfidence;
  policy.maxConcurrency = profile.maxConcurrency;
  policy.allowOnlineAdapter = profile.allowOnlineAdapter;
  return policy;
}

export function getProfile(policy) {
  return PROFILES[policy.profile] || PROFILES.balanced;
}

export function meetsConfidence(policy, confidence) {
  return Number(confidence || 0) >= Number(policy.minConfidence || 0);
}
