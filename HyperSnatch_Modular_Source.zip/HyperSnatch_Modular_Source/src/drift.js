function indexByUrl(list) {
  const m = new Map();
  for (const item of list || []) m.set(item.original, item);
  return m;
}

export function detectDecodeDrift(baseline, candidate) {
  const base = indexByUrl(baseline);
  const next = indexByUrl(candidate);
  const changed = [];
  const missing = [];
  const added = [];

  for (const [url, item] of base.entries()) {
    const c = next.get(url);
    if (!c) {
      missing.push(url);
      continue;
    }
    if (c.decoded !== item.decoded) {
      changed.push({ url, baseline: item.decoded, candidate: c.decoded });
    }
  }

  for (const [url] of next.entries()) {
    if (!base.has(url)) added.push(url);
  }

  return {
    ok: changed.length === 0 && missing.length === 0,
    changed,
    missing,
    added
  };
}
