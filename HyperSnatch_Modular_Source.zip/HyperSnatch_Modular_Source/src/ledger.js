async function sha256Hex(text, cryptoRef = crypto) {
  const digest = await cryptoRef.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(digest)).map(v => v.toString(16).padStart(2, "0")).join("");
}

export function createAuditLedger() {
  const entries = [];
  return {
    async append(event, cryptoRef = crypto) {
      const prevHash = entries.length ? entries[entries.length - 1].hash : "GENESIS";
      const payload = JSON.stringify({ prevHash, event, ts: new Date().toISOString() });
      const hash = await sha256Hex(payload, cryptoRef);
      const rec = { prevHash, event, hash };
      entries.push(rec);
      return rec;
    },
    all() {
      return [...entries];
    }
  };
}
