export const KeyRotationUI = {
  container: null,
  trustStore: null,
  onUpdate: null,
  
  init(containerId, trustStore, onUpdate) {
    this.container = document.getElementById(containerId);
    this.trustStore = trustStore;
    this.onUpdate = onUpdate;
    
    if (this.container) {
      this.render();
    }
  },
  
  render() {
    if (!this.container) return;
    
    const keys = this.trustStore?.keys || [];
    const activeKeys = keys.filter(k => !k.revoked);
    const revokedKeys = keys.filter(k => k.revoked);
    
    this.container.innerHTML = `
      <div class="key-rotation-panel">
        <div class="panel-header">
          <h3>🔐 Key Management</h3>
          <button class="btn-generate-key" data-action="generate">+ Generate New Key</button>
        </div>
        
        <div class="key-tabs">
          <button class="tab active" data-tab="active">Active (${activeKeys.length})</button>
          <button class="tab" data-tab="revoked">Revoked (${revokedKeys.length})</button>
        </div>
        
        <div class="tab-content active" id="tab-active">
          ${this.renderKeyList(activeKeys, "active")}
        </div>
        
        <div class="tab-content" id="tab-revoked">
          ${this.renderKeyList(revokedKeys, "revoked")}
        </div>
        
        ${this.renderRotationModal()}
      </div>
    `;
    
    this.attachEvents();
  },
  
  renderKeyList(keys, type) {
    if (keys.length === 0) {
      return `<div class="empty-state">No ${type} keys</div>`;
    }
    
    return keys.map(key => `
      <div class="key-card" data-key-id="${key.id}">
        <div class="key-header">
          <span class="key-label">${this.escapeHtml(key.label)}</span>
          <span class="key-id">${this.escapeHtml(key.id)}</span>
        </div>
        <div class="key-meta">
          <span>Added: ${key.addedAt || "Unknown"}</span>
          ${key.rotationCount ? `<span>Rotated: ${key.rotationCount}x</span>` : ""}
          ${key.lastRotated ? `<span>Last: ${key.lastRotated}</span>` : ""}
        </div>
        <div class="key-actions">
          ${type === "active" ? `
            <button class="btn-rotate" data-action="rotate" data-key-id="${key.id}">↻ Rotate</button>
            <button class="btn-export" data-action="export" data-key-id="${key.id}">↑ Export</button>
            <button class="btn-revoke" data-action="revoke" data-key-id="${key.id}">✗ Revoke</button>
          ` : `
            <button class="btn-restore" data-action="restore" data-key-id="${key.id}">↩ Restore</button>
            <button class="btn-delete" data-action="delete" data-key-id="${key.id}">🗑 Delete</button>
          `}
        </div>
      </div>
    `).join("");
  },
  
  renderRotationModal() {
    return `
      <div class="modal-overlay" id="rotation-modal" style="display: none;">
        <div class="modal">
          <div class="modal-header">
            <h4>Key Rotation</h4>
            <button class="modal-close" data-action="close-modal">×</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>Select Key to Rotate</label>
              <select id="rotate-key-select" class="form-control">
                ${(this.trustStore?.keys || []).filter(k => !k.revoked).map(k => 
                  `<option value="${k.id}">${this.escapeHtml(k.label)} (${k.id})</option>`
                ).join("")}
              </select>
            </div>
            
            <div class="form-group">
              <label>New Key Label</label>
              <input type="text" id="rotate-new-label" class="form-control" placeholder="e.g., Production Key v2">
            </div>
            
            <div class="form-group">
              <label>
                <input type="checkbox" id="rotate-keep-old"> Keep old key for verification
              </label>
            </div>
            
            <div class="warning-box">
              <strong>⚠️ Warning:</strong> Rotating this key will generate a new key pair. 
              Any data signed with the old key will need the old public key for verification.
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" data-action="close-modal">Cancel</button>
            <button class="btn-confirm-rotate" data-action="confirm-rotate">Rotate Key</button>
          </div>
        </div>
      </div>
    `;
  },
  
  attachEvents() {
    const panel = this.container;
    
    panel.querySelectorAll(".tab").forEach(tab => {
      tab.addEventListener("click", (e) => this.switchTab(e.target.dataset.tab));
    });
    
    panel.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", (e) => this.handleAction(e.target.dataset.action, e.target.dataset.keyId));
    });
  },
  
  switchTab(tabName) {
    this.container.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    this.container.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    
    this.container.querySelector(`[data-tab="${tabName}"]`).classList.add("active");
    this.container.querySelector(`#tab-${tabName}`).classList.add("active");
  },
  
  async handleAction(action, keyId) {
    switch (action) {
      case "generate":
        await this.generateKey();
        break;
      case "rotate":
        this.showModal("rotation-modal");
        break;
      case "confirm-rotate":
        await this.confirmRotation();
        break;
      case "export":
        await this.exportKey(keyId);
        break;
      case "revoke":
        await this.revokeKey(keyId);
        break;
      case "restore":
        await this.restoreKey(keyId);
        break;
      case "delete":
        await this.deleteKey(keyId);
        break;
      case "close-modal":
        this.hideModal("rotation-modal");
        break;
    }
  },
  
  async generateKey() {
    try {
      const { generateKeyPair } = await import("./signing.js");
      const keyPair = await generateKeyPair();
      
      const newKey = {
        id: `key-${Date.now()}`,
        label: `Key ${Date.now()}`,
        publicJwk: keyPair.publicJwk,
        privateJwk: keyPair.privateJwk,
        revoked: false,
        addedAt: new Date().toISOString(),
        rotationCount: 0
      };
      
      this.trustStore.keys.push(newKey);
      this.saveTrustStore();
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.trustStore);
      
      alert(`Key generated: ${newKey.id}`);
    } catch (e) {
      alert(`Failed to generate key: ${e.message}`);
    }
  },
  
  async confirmRotation() {
    const select = document.getElementById("rotate-key-select");
    const labelInput = document.getElementById("rotate-new-label");
    const keepOld = document.getElementById("rotate-keep-old");
    
    const oldKeyId = select.value;
    const newLabel = labelInput.value || `Rotated Key from ${oldKeyId}`;
    
    try {
      const { generateKeyPair } = await import("./signing.js");
      const keyPair = await generateKeyPair();
      
      const oldKey = this.trustStore.keys.find(k => k.id === oldKeyId);
      if (oldKey) {
        oldKey.rotationCount = (oldKey.rotationCount || 0) + 1;
        oldKey.lastRotated = new Date().toISOString();
      }
      
      const newKey = {
        id: `key-${Date.now()}`,
        label: newLabel,
        publicJwk: keyPair.publicJwk,
        privateJwk: keepOld.checked ? null : keyPair.privateJwk,
        revoked: false,
        addedAt: new Date().toISOString(),
        rotationCount: 0,
        rotatedFrom: oldKeyId
      };
      
      this.trustStore.keys.push(newKey);
      this.saveTrustStore();
      this.hideModal("rotation-modal");
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.trustStore);
      
      alert(`Key rotated! New key: ${newKey.id}`);
    } catch (e) {
      alert(`Rotation failed: ${e.message}`);
    }
  },
  
  async exportKey(keyId) {
    const key = this.trustStore.keys.find(k => k.id === keyId);
    if (!key) return;
    
    const exportData = {
      id: key.id,
      label: key.label,
      publicJwk: key.publicJwk,
      addedAt: key.addedAt
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hyperSnatch-key-${keyId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  },
  
  async revokeKey(keyId) {
    if (!confirm("Are you sure you want to revoke this key? This action cannot be undone.")) {
      return;
    }
    
    const key = this.trustStore.keys.find(k => k.id === keyId);
    if (key) {
      key.revoked = true;
      key.revokedAt = new Date().toISOString();
      this.saveTrustStore();
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.trustStore);
    }
  },
  
  async restoreKey(keyId) {
    const key = this.trustStore.keys.find(k => k.id === keyId);
    if (key) {
      key.revoked = false;
      key.restoredAt = new Date().toISOString();
      delete key.revokedAt;
      this.saveTrustStore();
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.trustStore);
    }
  },
  
  async deleteKey(keyId) {
    if (!confirm("Permanently delete this key? This cannot be undone.")) {
      return;
    }
    
    this.trustStore.keys = this.trustStore.keys.filter(k => k.id !== keyId);
    this.saveTrustStore();
    this.render();
    
    if (this.onUpdate) this.onUpdate(this.trustStore);
  },
  
  saveTrustStore() {
    localStorage.setItem("hs-trust-store", JSON.stringify(this.trustStore));
  },
  
  showModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = "flex";
  },
  
  hideModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = "none";
  },
  
  escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
};

export function attachKeyRotationUI(containerId, trustStore, onUpdate) {
  return KeyRotationUI.init(containerId, trustStore, onUpdate);
}
