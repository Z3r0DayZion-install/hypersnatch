export function extractStreamCandidates(html, baseUrl = "") {
  const text = String(html || "");
  const out = new Set();
  const patterns = [
    /(https?:\/\/[^\s"'<>]+?\.(?:mp4|m3u8)(?:\?[^\s"'<>]*)?)/gi,
    /["'](\/[^"']+\.(?:mp4|m3u8)(?:\?[^"']*)?)["']/gi
  ];
  for (const rx of patterns) {
    let m;
    while ((m = rx.exec(text))) {
      const val = m[1] || "";
      if (!val) continue;
      if (val.startsWith("/")) {
        try {
          out.add(new URL(val, baseUrl).href);
        } catch {}
      } else {
        out.add(val);
      }
    }
  }
  return [...out];
}

export async function decodeViaOnlineAdapter(url, fetchImpl = fetch) {
  const response = await fetchImpl(url, { method: "GET" });
  if (!response.ok) return { ok: false, reason: "Adapter fetch failed" };
  const html = await response.text();
  const candidates = extractStreamCandidates(html, url);
  if (!candidates.length) return { ok: false, reason: "Adapter found no stream candidates" };
  return { ok: true, decoded: candidates[0], candidates };
}
