function b64(bytes) {
  let s = "";
  bytes.forEach(b => { s += String.fromCharCode(b); });
  return btoa(s);
}

function fromB64(str) {
  const bin = atob(str);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
  return out;
}

const ALG = { name: "ECDSA", namedCurve: "P-256" };
const SIGN_PARAMS = { name: "ECDSA", hash: "SHA-256" };

export async function generateSigningKeyPair(cryptoRef = crypto) {
  return cryptoRef.subtle.generateKey(ALG, true, ["sign", "verify"]);
}

export async function exportPublicJwk(publicKey, cryptoRef = crypto) {
  return cryptoRef.subtle.exportKey("jwk", publicKey);
}

export async function exportPrivateJwk(privateKey, cryptoRef = crypto) {
  return cryptoRef.subtle.exportKey("jwk", privateKey);
}

export async function importPublicJwk(jwk, cryptoRef = crypto) {
  return cryptoRef.subtle.importKey("jwk", jwk, ALG, true, ["verify"]);
}

export async function importPrivateJwk(jwk, cryptoRef = crypto) {
  return cryptoRef.subtle.importKey("jwk", jwk, ALG, true, ["sign"]);
}

export async function signText(text, privateKey, cryptoRef = crypto) {
  const sig = await cryptoRef.subtle.sign(SIGN_PARAMS, privateKey, new TextEncoder().encode(text));
  return b64(new Uint8Array(sig));
}

export async function verifyTextSignature(text, signatureB64, publicKey, cryptoRef = crypto) {
  return cryptoRef.subtle.verify(
    SIGN_PARAMS,
    publicKey,
    fromB64(signatureB64),
    new TextEncoder().encode(text)
  );
}
