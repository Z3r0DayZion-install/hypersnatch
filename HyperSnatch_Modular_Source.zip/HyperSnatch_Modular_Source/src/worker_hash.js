export function createHashWorker() {
  const workerCode = `
    self.onmessage = async function(e) {
      const { id, data, algorithm = 'SHA-256' } = e.data;
      
      try {
        const msgBuffer = new TextEncoder().encode(data);
        const hashBuffer = await crypto.subtle.digest(algorithm, msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        
        self.postMessage({ id, success: true, hash: hashHex });
      } catch (error) {
        self.postMessage({ id, success: false, error: error.message });
      }
    };
  `;
  
  const blob = new Blob([workerCode], { type: "application/javascript" });
  const url = URL.createObjectURL(blob);
  const worker = new Worker(url);
  
  return {
    worker,
    url,
    async hash(data, id = "default") {
      return new Promise((resolve, reject) => {
        const handler = (e) => {
          if (e.data.id === id) {
            worker.removeEventListener("message", handler);
            if (e.data.success) {
              resolve(e.data.hash);
            } else {
              reject(new Error(e.data.error));
            }
          }
        };
        
        worker.addEventListener("message", handler);
        worker.postMessage({ id, data, algorithm: "SHA-256" });
      });
    },
    terminate() {
      worker.terminate();
      URL.revokeObjectURL(url);
    }
  };
}

export function createBulkHasher(options = {}) {
  const { maxConcurrent = 4 } = options;
  const queue = [];
  const inProgress = new Map();
  const results = new Map();
  let workerPool = [];
  let nextId = 0;
  
  function createWorker() {
    const workerCode = `
      self.onmessage = async function(e) {
        const { id, data, algorithm } = e.data;
        try {
          const msgBuffer = new TextEncoder().encode(data);
          const hashBuffer = await crypto.subtle.digest(algorithm || 'SHA-256', msgBuffer);
          const hashArray = Array.from(new Uint8Array(hashBuffer));
          const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
          self.postMessage({ id, success: true, hash: hashHex });
        } catch (error) {
          self.postMessage({ id, success: false, error: error.message });
        }
      };
    `;
    
    const blob = new Blob([workerCode], { type: "application/javascript" });
    const url = URL.createObjectURL(blob);
    return new Worker(url);
  }
  
  function getWorker() {
    if (workerPool.length > 0) {
      return workerPool.pop();
    }
    if (inProgress.size < maxConcurrent) {
      return createWorker();
    }
    return null;
  }
  
  function returnWorker(worker) {
    if (workerPool.length < maxConcurrent) {
      workerPool.push(worker);
    } else {
      worker.terminate();
    }
  }
  
  function processQueue() {
    while (queue.length > 0 && inProgress.size < maxConcurrent) {
      const { data, id, resolve, reject } = queue.shift();
      const worker = getWorker();
      
      if (!worker) {
        queue.unshift({ data, id, resolve, reject });
        break;
      }
      
      inProgress.set(id, worker);
      
      const handler = (e) => {
        if (e.data.id === id) {
          worker.removeEventListener("message", handler);
          inProgress.delete(id);
          returnWorker(worker);
          
          if (e.data.success) {
            results.set(id, e.data.hash);
            resolve(e.data.hash);
          } else {
            reject(new Error(e.data.error));
          }
          
          processQueue();
        }
      };
      
      worker.addEventListener("message", handler);
      worker.postMessage({ id, data: "SHA-256" });
    }
  }
  
  return {
    async hash(data) {
      const id = `hash-${nextId++}`;
      
      return new Promise((resolve, reject) => {
        queue.push({ data, id, resolve, reject });
        processQueue();
      });
    },
    
    async hashMany(items) {
      return Promise.all(items.map(item => this.hash(item)));
    },
    
    getResult(id) {
      return results.get(id);
    },
    
    terminate() {
      workerPool.forEach(w => w.terminate());
      workerPool = [];
      inProgress.forEach(w => w.terminate());
      inProgress.clear();
      queue.length = 0;
    },
    
    getStats() {
      return {
        queued: queue.length,
        inProgress: inProgress.size,
        poolSize: workerPool.length
      };
    }
  };
}

export async function hashLargeData(data, options = {}, cryptoRef = crypto) {
  const { useWorker = false, chunkSize = 1024 * 1024 } = options;
  
  if (useWorker && typeof Worker !== "undefined") {
    const hasher = createHashWorker();
    try {
      return await hasher.hash(data);
    } finally {
      hasher.terminate();
    }
  }
  
  const msgBuffer = new TextEncoder().encode(data);
  const hashBuffer = await cryptoRef.subtle.digest("SHA-256", msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

export function streamingHash(file, options = {}, onProgress) {
  const { chunkSize = 1024 * 1024 } = options;
  
  return new Promise((resolve, reject) => {
    const hashAlgo = "SHA-256";
    let offset = 0;
    const chunks = [];
    
    function readNextChunk() {
      const slice = file.slice(offset, offset + chunkSize);
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        chunks.push(new Uint8Array(e.target.result));
        offset += chunkSize;
        
        if (onProgress) {
          onProgress({
            loaded: offset,
            total: file.size,
            percent: Math.round((offset / file.size) * 100)
          });
        }
        
        if (offset < file.size) {
          readNextChunk();
        } else {
          try {
            const allBytes = new Uint8Array(chunks.reduce((acc, c) => acc + c.length, 0));
            let pos = 0;
            for (const chunk of chunks) {
              allBytes.set(chunk, pos);
              pos += chunk.length;
            }
            
            const digest = await crypto.subtle.digest(hashAlgo, allBytes);
            const hashArray = Array.from(new Uint8Array(digest));
            resolve(hashArray.map(b => b.toString(16).padStart(2, "0")).join(""));
          } catch (err) {
            reject(err);
          }
        }
      };
      
      reader.onerror = () => reject(reader.error);
      reader.readAsArrayBuffer(slice);
    }
    
    readNextChunk();
  });
}
