import { validateWithErrors, getSchemaType, SchemaType } from "./schema_validator.js";

export const VerifyPanel = {
  render(container, pack) {
    if (!container) return;
    
    container.innerHTML = "";
    
    const type = getSchemaType(pack);
    const validation = validateWithErrors(pack);
    
    const panel = document.createElement("div");
    panel.className = "verify-panel";
    panel.innerHTML = this.buildPanelHTML(type, validation, pack);
    
    container.appendChild(panel);
    this.attachEventListeners(panel, pack, validation);
  },
  
  buildPanelHTML(type, validation, pack) {
    const statusClass = validation.valid ? "status-valid" : "status-invalid";
    const statusText = validation.valid ? "✓ VALID" : "✗ INVALID";
    
    let detailsHTML = "";
    
    if (type === SchemaType.tearV2) {
      detailsHTML = this.renderTearV2Details(pack);
    } else if (type === SchemaType.tearBundle) {
      detailsHTML = this.renderBundleDetails(pack);
    } else if (type === SchemaType.releaseManifest) {
      detailsHTML = this.renderManifestDetails(pack);
    } else if (type === SchemaType.trustStore) {
      detailsHTML = this.renderTrustStoreDetails(pack);
    } else if (type === SchemaType.doctorReport) {
      detailsHTML = this.renderDoctorReportDetails(pack);
    } else {
      detailsHTML = `<div class="detail-section"><p>Unknown format: ${type}</p></div>`;
    }
    
    let errorsHTML = "";
    if (!validation.valid) {
      errorsHTML = `
        <div class="errors-section">
          <h4>Validation Errors</h4>
          <ul>
            ${validation.errors.map(e => `<li><strong>${e.path.join(".")}:</strong> ${e.message}</li>`).join("")}
          </ul>
        </div>
      `;
    }
    
    return `
      <div class="verify-header ${statusClass}">
        <span class="verify-status">${statusText}</span>
        <span class="verify-type">${type || "Unknown"}</span>
      </div>
      ${errorsHTML}
      <div class="verify-details">
        ${detailsHTML}
      </div>
      <div class="verify-actions">
        <button class="btn-verify-full" data-action="full-check">Run Full Check</button>
        <button class="btn-export-report" data-action="export-report">Export Report</button>
      </div>
    `;
  },
  
  renderTearV2Details(pack) {
    return `
      <div class="detail-section">
        <h4>Pack Information</h4>
        <table class="detail-table">
          <tr><td>Format</td><td>${pack.format}</td></tr>
          <tr><td>Schema Version</td><td>${pack.schemaVersion}</td></tr>
          <tr><td>App</td><td>${pack.app}</td></tr>
          <tr><td>App Version</td><td>${pack.appVersion}</td></tr>
          <tr><td>Kind</td><td>${pack.kind}</td></tr>
          <tr><td>Created</td><td>${pack.createdAt}</td></tr>
        </table>
      </div>
      <div class="detail-section">
        <h4>Cryptography</h4>
        <table class="detail-table">
          <tr><td>KDF</td><td>${pack.kdf}</td></tr>
          <tr><td>Iterations</td><td>${pack.iterations}</td></tr>
          <tr><td>Salt (b64)</td><td class="truncate">${pack.salt?.slice(0, 20)}...</td></tr>
          <tr><td>IV (b64)</td><td class="truncate">${pack.iv?.slice(0, 20)}...</td></tr>
          <tr><td>Digest (sha256)</td><td class="truncate">${pack.digest?.slice(0, 20)}...</td></tr>
          <tr><td>Data Size</td><td>${pack.data?.length} bytes</td></tr>
        </table>
      </div>
      <div class="detail-section">
        <h4>Signature</h4>
        ${pack.signature ? `
          <table class="detail-table">
            <tr><td>Algorithm</td><td>${pack.signature.alg}</td></tr>
            <tr><td>Key ID</td><td>${pack.signature.keyId}</td></tr>
            <tr><td>Signature</td><td class="truncate">${pack.signature.sig?.slice(0, 30)}...</td></tr>
          </table>
        ` : `<p class="no-sig">No signature present</p>`}
      </div>
    `;
  },
  
  renderBundleDetails(pack) {
    const entries = pack.manifest?.entries || [];
    const entriesHTML = entries.map(e => `
      <tr>
        <td>${e.path}</td>
        <td>${e.type}</td>
        <td>${e.size}</td>
        <td class="truncate">${e.sha256?.slice(0, 16)}...</td>
      </tr>
    `).join("");
    
    return `
      <div class="detail-section">
        <h4>Bundle Information</h4>
        <table class="detail-table">
          <tr><td>Schema</td><td>${pack.schema}</td></tr>
          <tr><td>Schema Version</td><td>${pack.schemaVersion}</td></tr>
          <tr><td>App</td><td>${pack.app}</td></tr>
          <tr><td>App Version</td><td>${pack.appVersion}</td></tr>
          <tr><td>Created</td><td>${pack.createdAt}</td></tr>
          <tr><td>Deterministic</td><td>${pack.deterministic ? "Yes" : "No"}</td></tr>
        </table>
      </div>
      <div class="detail-section">
        <h4>Manifest Entries (${entries.length})</h4>
        <table class="detail-table entries-table">
          <thead>
            <tr><th>Path</th><th>Type</th><th>Size</th><th>SHA256</th></tr>
          </thead>
          <tbody>${entriesHTML}</tbody>
        </table>
      </div>
      ${pack.payload ? `
        <div class="detail-section">
          <h4>Payload</h4>
          <table class="detail-table">
            <tr><td>Format</td><td>${pack.payload.format}</td></tr>
            <tr><td>Digest</td><td class="truncate">${pack.payload.digest?.slice(0, 20)}...</td></tr>
          </table>
        </div>
      ` : ""}
      ${pack.signature ? `
        <div class="detail-section">
          <h4>Signature</h4>
          <table class="detail-table">
            <tr><td>Algorithm</td><td>${pack.signature.alg}</td></tr>
            <tr><td>Key ID</td><td>${pack.signature.keyId}</td></tr>
          </table>
        </div>
      ` : ""}
    `;
  },
  
  renderManifestDetails(pack) {
    const items = pack.items || [];
    const itemsHTML = items.map(i => `
      <tr>
        <td>${i.path}</td>
        <td>${i.bytes}</td>
        <td class="truncate">${i.sha256?.slice(0, 20)}...</td>
      </tr>
    `).join("");
    
    return `
      <div class="detail-section">
        <h4>Manifest Information</h4>
        <table class="detail-table">
          <tr><td>Format</td><td>${pack.format}</td></tr>
          <tr><td>Created</td><td>${pack.createdAt}</td></tr>
          <tr><td>Items</td><td>${items.length}</td></tr>
        </table>
      </div>
      <div class="detail-section">
        <h4>Artifacts</h4>
        <table class="detail-table entries-table">
          <thead>
            <tr><th>Path</th><th>Bytes</th><th>SHA256</th></tr>
          </thead>
          <tbody>${itemsHTML}</tbody>
        </table>
      </div>
      ${pack.signature ? `
        <div class="detail-section">
          <h4>Signature</h4>
          <table class="detail-table">
            <tr><td>Algorithm</td><td>${pack.signature.alg}</td></tr>
            <tr><td>Key ID</td><td>${pack.signature.keyId}</td></tr>
          </table>
        </div>
      ` : ""}
    `;
  },
  
  renderTrustStoreDetails(pack) {
    const keys = pack.keys || [];
    const keysHTML = keys.map(k => `
      <tr>
        <td>${k.id}</td>
        <td>${k.label}</td>
        <td>${k.revoked ? "✗ Revoked" : "✓ Active"}</td>
        <td>${k.addedAt || "N/A"}</td>
      </tr>
    `).join("");
    
    return `
      <div class="detail-section">
        <h4>Trust Store</h4>
        <table class="detail-table">
          <tr><td>Format</td><td>${pack.format}</td></tr>
          <tr><td>Schema Version</td><td>${pack.schemaVersion}</td></tr>
          <tr><td>Keys</td><td>${keys.length}</td></tr>
        </table>
      </div>
      <div class="detail-section">
        <h4>Keys</h4>
        <table class="detail-table entries-table">
          <thead>
            <tr><th>ID</th><th>Label</th><th>Status</th><th>Added</th></tr>
          </thead>
          <tbody>${keysHTML}</tbody>
        </table>
      </div>
    `;
  },
  
  renderDoctorReportDetails(pack) {
    const checks = pack.checks || [];
    const checksHTML = checks.map(c => `
      <tr>
        <td>${c.name}</td>
        <td class="status-${c.status}">${c.status}</td>
        <td>${c.details || "-"}</td>
        <td>${c.durationMs ? c.durationMs + "ms" : "-"}</td>
      </tr>
    `).join("");
    
    return `
      <div class="detail-section">
        <h4>Doctor Report</h4>
        <table class="detail-table">
          <tr><td>Format</td><td>${pack.format}</td></tr>
          <tr><td>App</td><td>${pack.app}</td></tr>
          <tr><td>Version</td><td>${pack.appVersion}</td></tr>
          <tr><td>Created</td><td>${pack.createdAt}</td></tr>
          <tr><td>Deterministic</td><td>${pack.deterministic ? "Yes" : "No"}</td></tr>
        </table>
      </div>
      <div class="detail-section">
        <h4>Checks (${checks.length})</h4>
        <table class="detail-table entries-table">
          <thead>
            <tr><th>Name</th><th>Status</th><th>Details</th><th>Duration</th></tr>
          </thead>
          <tbody>${checksHTML}</tbody>
        </table>
      </div>
      ${pack.signature ? `
        <div class="detail-section">
          <h4>Signature</h4>
          <table class="detail-table">
            <tr><td>Algorithm</td><td>${pack.signature.alg}</td></tr>
            <tr><td>Key ID</td><td>${pack.signature.keyId}</td></tr>
          </table>
        </div>
      ` : ""}
    `;
  },
  
  attachEventListeners(panel, pack, validation) {
    const fullCheckBtn = panel.querySelector(".btn-verify-full");
    const exportBtn = panel.querySelector(".btn-export-report");
    
    if (fullCheckBtn) {
      fullCheckBtn.addEventListener("click", () => this.runFullCheck(pack));
    }
    
    if (exportBtn) {
      exportBtn.addEventListener("click", () => this.exportReport(pack, validation));
    }
  },
  
  async runFullCheck(pack) {
    const results = {
      schema: validateWithErrors(pack),
      structure: this.checkStructure(pack),
      timestamp: new Date().toISOString()
    };
    
    console.log("Full check results:", results);
    return results;
  },
  
  checkStructure(pack) {
    const issues = [];
    
    if (!pack.format && !pack.schema) {
      issues.push("Missing format/schema field");
    }
    
    if (pack.signature && !pack.signature.keyId) {
      issues.push("Signature missing keyId");
    }
    
    return { valid: issues.length === 0, issues };
  },
  
  exportReport(pack, validation) {
    const report = {
      type: "verify-report",
      generatedAt: new Date().toISOString(),
      schemaType: getSchemaType(pack),
      validation,
      raw: pack
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "verify_report.json";
    a.click();
    URL.revokeObjectURL(url);
  }
};

export function attachVerifyPanel(containerId) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.warn(`Container #${containerId} not found`);
    return;
  }
  
  return {
    show(pack) {
      VerifyPanel.render(container, pack);
    },
    hide() {
      container.innerHTML = "";
    }
  };
}
