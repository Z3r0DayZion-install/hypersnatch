export function createCircuitBreaker() {
  const map = new Map();
  return {
    recordFailure(host) {
      const rec = map.get(host) || { failures: 0, open: false, openedAt: 0 };
      rec.failures += 1;
      map.set(host, rec);
      return rec;
    },
    recordSuccess(host) {
      const rec = map.get(host) || { failures: 0, open: false, openedAt: 0 };
      rec.failures = Math.max(0, rec.failures - 1);
      if (rec.failures === 0) rec.open = false;
      map.set(host, rec);
      return rec;
    },
    evaluate(host, threshold) {
      const rec = map.get(host) || { failures: 0, open: false, openedAt: 0 };
      if (rec.failures >= threshold) {
        rec.open = true;
        if (!rec.openedAt) rec.openedAt = Date.now();
      }
      map.set(host, rec);
      return rec;
    },
    isOpen(host) {
      return !!map.get(host)?.open;
    },
    status() {
      return Array.from(map.entries()).map(([host, rec]) => ({ host, ...rec }));
    },
    reset(host) {
      if (host) map.delete(host);
      else map.clear();
    }
  };
}
