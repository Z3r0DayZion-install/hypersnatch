const URL_RX = /https?:\/\/[^\s"'<>]+/gi;

export function sanitizeUrl(url) {
  return String(url || "").trim().replace(/[),.;]+$/, "");
}

export function extractUrls(text) {
  const matches = String(text || "").match(URL_RX) || [];
  return matches.map(sanitizeUrl).filter(Boolean);
}

export function extractFolderId(url) {
  const clean = sanitizeUrl(url);
  const match = clean.match(/\/folder\/([a-z0-9_-]+)/i) || clean.match(/[?&]folder=([a-z0-9_-]+)/i);
  return match ? match[1] : "";
}

export function parseQueueInput(text, source = "manual") {
  const seen = new Set();
  const out = [];
  for (const url of extractUrls(text)) {
    if (seen.has(url)) continue;
    seen.add(url);
    out.push({
      url,
      folderId: extractFolderId(url),
      source
    });
  }
  return out;
}
