import { detectHost, gateHost, isSupportedHost } from "./router.js";
import { decodeViaOnlineAdapter } from "./online_adapter.js";
import { createStrategyRegistry } from "./strategies.js";

const strategyRegistry = createStrategyRegistry();

function extOf(url) {
  return (url.match(/\.([a-z0-9]{2,5})(?:[?#]|$)/i) || [,"bin"])[1].toLowerCase();
}

function parseSizeHint(urlObj) {
  const raw = urlObj.searchParams.get("size");
  if (!raw) return "unknown";
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) return "unknown";
  return (n / (1024 * 1024)).toFixed(2) + " MB";
}

export function buildMetadata(decodedUrl, host, sourceUrlObj) {
  const extension = extOf(decodedUrl);
  const filename = decodedUrl.split("/").pop().split("?")[0] || `${host}-asset.${extension}`;
  const mime = extension === "mp4"
    ? "video/mp4"
    : extension === "m3u8"
      ? "application/x-mpegURL"
      : "application/octet-stream";
  return {
    filename,
    size: parseSizeHint(sourceUrlObj),
    type: mime,
    host,
    detectedAt: new Date().toISOString()
  };
}

export function decode(url, tier) {
  const host = detectHost(url);
  if (!host) return { ok: false, reason: "Malformed URL" };
  if (!isSupportedHost(host)) return { ok: false, reason: "Unsupported host" };
  const gate = gateHost(host, tier);
  if (!gate.ok) return { ok: false, reason: gate.reason };

  const u = new URL(url);
  const strategyResult = strategyRegistry.apply({ host, urlObj: u, url });
  const decoded = strategyResult?.decoded || "";

  if (!decoded) return { ok: false, reason: "No local decode path" };
  return {
    ok: true,
    host,
    decoded,
    meta: buildMetadata(decoded, host, u),
    confidence: strategyResult?.confidence ?? 0.6,
    provenance: {
      strategyId: strategyResult?.strategyId || "unknown",
      path: "local"
    }
  };
}

export function decodeFromHtml(htmlContent, sourceUrl, tier) {
  const host = detectHost(sourceUrl);
  if (!host) return { ok: false, reason: "Malformed source URL" };
  
  if (!isSupportedHost(host)) return { ok: false, reason: "Unsupported host" };
  const gate = gateHost(host, tier);
  if (!gate.ok) return { ok: false, reason: gate.reason };

  if (!htmlContent || typeof htmlContent !== "string") {
    return { ok: false, reason: "Invalid HTML content" };
  }

  const strategyResult = strategyRegistry.applyWithHtml({ 
    host, 
    html: htmlContent, 
    url: sourceUrl 
  });
  
  const decoded = strategyResult?.decoded || "";

  if (!decoded) return { ok: false, reason: "No download link found in HTML" };

  const sourceUrlObj = new URL(sourceUrl);
  return {
    ok: true,
    host,
    decoded,
    meta: buildMetadata(decoded, host, sourceUrlObj),
    confidence: strategyResult?.confidence ?? 0.6,
    method: strategyResult?.method || "dom-extract",
    provenance: {
      strategyId: strategyResult?.strategyId || "dom-extract",
      path: "html-content",
      sourceUrl
    }
  };
}

export function extractAllDownloadLinks(htmlContent) {
  const results = {
    directLinks: [],
    emloadLinks: [],
    ksharedLinks: [],
    rapidgatorLinks: [],
    otherLinks: []
  };
  
  if (typeof DOMParser === "undefined") {
    return results;
  }
  
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlContent, "text/html");
  
  const allAnchors = doc.querySelectorAll("a[href]");
  
  for (const a of allAnchors) {
    const href = a.href;
    if (!href || !href.startsWith("http")) continue;
    
    const link = {
      url: href,
      text: a.textContent?.trim().slice(0, 50) || "",
      isDownload: a.hasAttribute("download") || href.includes("download")
    };
    
    if (href.includes("emload.com")) {
      results.emloadLinks.push(link);
    } else if (href.includes("kshared.com")) {
      results.ksharedLinks.push(link);
    } else if (href.includes("rapidgator.net")) {
      results.rapidgatorLinks.push(link);
    } else if (link.isDownload || href.match(/\.(mp4|zip|rar|pdf|exe|iso|7z|avi|mkv)/i)) {
      results.directLinks.push(link);
    } else {
      results.otherLinks.push(link);
    }
  }
  
  return results;
}

export async function decodeWithAdapter(url, tier, options = {}) {
  const local = decode(url, tier);
  if (local.ok) return local;
  if (local.reason !== "No local decode path") return local;
  if (!options.enableOnlineAdapter) return local;
  const host = detectHost(url);
  if (!host || !isSupportedHost(host)) return local;
  const gate = gateHost(host, tier);
  if (!gate.ok) return { ok: false, reason: gate.reason };
  const adapted = await decodeViaOnlineAdapter(url, options.fetchImpl || fetch);
  if (!adapted.ok) return { ok: false, reason: adapted.reason };
  const sourceUrlObj = new URL(url);
  return {
    ok: true,
    host,
    decoded: adapted.decoded,
    meta: buildMetadata(adapted.decoded, host, sourceUrlObj),
    adapterCandidates: adapted.candidates,
    confidence: 0.55,
    provenance: {
      strategyId: "online-adapter",
      path: "network"
    }
  };
}

export function registerDecodeStrategy(strategy) {
  return strategyRegistry.register(strategy);
}
