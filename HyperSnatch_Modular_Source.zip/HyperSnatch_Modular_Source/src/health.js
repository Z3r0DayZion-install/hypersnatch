export function runHealthChecks(engineLike) {
  const checks = [];
  const state = engineLike?.state || {};
  checks.push({
    id: "state-shape",
    ok: Array.isArray(state.queue) && Array.isArray(state.decoded) && Array.isArray(state.deferred),
    msg: "engine state collections available"
  });
  checks.push({
    id: "tier-value",
    ok: state.tier === "basic" || state.tier === "advanced",
    msg: "tier value is valid"
  });
  checks.push({
    id: "no-nan-counts",
    ok: Number.isFinite((state.queue || []).length) && Number.isFinite((state.decoded || []).length),
    msg: "counts are numeric"
  });
  return {
    ok: checks.every(c => c.ok),
    checks
  };
}
