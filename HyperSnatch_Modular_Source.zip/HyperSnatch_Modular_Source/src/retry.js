export function nextDelayMs(attempts) {
  const base = 5000;
  return Math.min(120000, base * Math.max(1, attempts));
}

export class RetryMemory {
  constructor() {
    this.map = new Map();
  }

  defer(url, reason, now = Date.now()) {
    const prev = this.map.get(url) || { attempts: 0 };
    const attempts = prev.attempts + 1;
    const nextTryAt = now + nextDelayMs(attempts);
    const rec = { url, reason, attempts, nextTryAt };
    this.map.set(url, rec);
    return rec;
  }

  ready(now = Date.now()) {
    const out = [];
    for (const rec of this.map.values()) {
      if (rec.nextTryAt <= now) out.push(rec);
    }
    return out;
  }

  pending(now = Date.now()) {
    const out = [];
    for (const rec of this.map.values()) {
      if (rec.nextTryAt > now) out.push(rec);
    }
    return out;
  }
}
