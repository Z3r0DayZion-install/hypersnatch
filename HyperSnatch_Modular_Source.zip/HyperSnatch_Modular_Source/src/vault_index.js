export const VaultIndex = {
  db: null,
  DB_NAME: "HyperSnatchVault",
  STORE_NAME: "items",
  
  async open() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, 1);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        if (!db.objectStoreNames.contains(this.STORE_NAME)) {
          const store = db.createObjectStore(this.STORE_NAME, { keyPath: "id" });
          store.createIndex("kind", "kind", { unique: false });
          store.createIndex("createdAt", "createdAt", { unique: false });
          store.createIndex("tags", "tags", { unique: false, multiEntry: true });
          store.createIndex("host", "host", { unique: false });
        }
      };
    });
  },
  
  async add(item) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readwrite");
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.put({
        ...item,
        addedAt: new Date().toISOString()
      });
      
      request.onsuccess = () => resolve(item.id);
      request.onerror = () => reject(request.error);
    });
  },
  
  async get(id) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readonly");
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.get(id);
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },
  
  async getAll() {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readonly");
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.getAll();
      
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  },
  
  async delete(id) {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readwrite");
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.delete(id);
      
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  },
  
  async search(query, options = {}) {
    const { kind, tags, host, limit = 50, offset = 0 } = options;
    
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readonly");
      const store = tx.objectStore(this.STORE_NAME);
      const results = [];
      const request = store.openCursor();
      
      const queryLower = query?.toLowerCase() || "";
      
      request.onsuccess = (event) => {
        const cursor = event.target.result;
        
        if (cursor) {
          const item = cursor.value;
          let match = true;
          
          if (queryLower) {
            const searchText = [
              item.id,
              item.name,
              item.kind,
              item.host,
              item.url,
              item.description,
              ...(item.tags || [])
            ].join(" ").toLowerCase();
            
            match = searchText.includes(queryLower);
          }
          
          if (match && kind && item.kind !== kind) match = false;
          if (match && host && item.host !== host) match = false;
          if (match && tags?.length) {
            const itemTags = item.tags || [];
            match = tags.every(t => itemTags.includes(t));
          }
          
          if (match) {
            results.push(item);
          }
          
          if (results.length < limit + offset) {
            cursor.continue();
          } else {
            resolve(results.slice(offset, offset + limit));
          }
        } else {
          resolve(results.slice(offset, offset + limit));
        }
      };
      
      request.onerror = () => reject(request.error);
    });
  },
  
  async count() {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readonly");
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.count();
      
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },
  
  async clear() {
    if (!this.db) await this.open();
    
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.STORE_NAME, "readwrite");
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.clear();
      
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  },
  
  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
};

export async function indexVaultItems(items) {
  for (const item of items) {
    await VaultIndex.add(item);
  }
}

export async function searchVault(query, options) {
  return VaultIndex.search(query, options);
}

export async function getVaultStats() {
  const items = await VaultIndex.getAll();
  
  const byKind = {};
  const byHost = {};
  const allTags = new Set();
  
  for (const item of items) {
    byKind[item.kind] = (byKind[item.kind] || 0) + 1;
    if (item.host) {
      byHost[item.host] = (byHost[item.host] || 0) + 1;
    }
    if (item.tags) {
      item.tags.forEach(t => allTags.add(t));
    }
  }
  
  return {
    total: items.length,
    byKind,
    byHost,
    tags: Array.from(allTags),
    oldest: items.length ? items.sort((a, b) => 
      new Date(a.createdAt) - new Date(b.createdAt)
    )[0]?.createdAt : null,
    newest: items.length ? items.sort((a, b) => 
      new Date(b.createdAt) - new Date(a.createdAt)
    )[0]?.createdAt : null
  };
}
