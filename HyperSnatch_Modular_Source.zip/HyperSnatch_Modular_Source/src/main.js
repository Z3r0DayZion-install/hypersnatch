import { state, log } from "./state.js";
import { exportTear } from "./export.js";
import { render } from "./ui.js";
import { createEngine } from "./engine.js";

const inbox = document.getElementById("inbox");
const decodeBtn = document.getElementById("decodeBtn");
const retryBtn = document.getElementById("retryBtn");
const exportBtn = document.getElementById("exportBtn");
const engine = createEngine({ tier: state.tier });

decodeBtn.addEventListener("click", async () => {
  engine.enqueue(inbox.value, "manual");
  const result = await engine.runQueueConcurrent(Date.now(), {
    concurrency: engine.policy.maxConcurrency,
    enableOnlineAdapter: false
  });
  state.decoded = engine.state.decoded;
  state.deferred = engine.state.deferred;
  log(`Queue run complete: decoded=${result.decodedCount} deferred=${result.deferredCount}`);
  render();
});

retryBtn.addEventListener("click", async () => {
  const moved = engine.retryReady();
  const result = await engine.runQueueConcurrent(Date.now(), {
    concurrency: engine.policy.maxConcurrency,
    enableOnlineAdapter: false
  });
  state.decoded = engine.state.decoded;
  state.deferred = engine.state.deferred;
  log(`Retry run: moved=${moved} decoded=${result.decodedCount} deferred=${result.deferredCount}`);
  render();
});

exportBtn.addEventListener("click", async () => {
  const passphrase = prompt("Passphrase for .tear export:");
  if (!passphrase) return;
  await exportTear({ decoded: engine.state.decoded, deferred: engine.state.deferred }, passphrase);
  log("Exported .tear");
  render();
});

log("Modular source initialized");
render();
