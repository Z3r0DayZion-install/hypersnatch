const B64_RX = /^[A-Za-z0-9+/]+={0,2}$/;

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isB64(value) {
  return typeof value === "string" && value.length > 0 && B64_RX.test(value);
}

export function validatePack(pack) {
  if (!isObject(pack)) throw new Error("Pack must be an object");
  if (pack.format !== "tear-v2") throw new Error("Unsupported format");
  if (pack.schemaVersion !== 2) throw new Error("Unsupported schema version");
  if (!["PBKDF2-SHA256"].includes(pack.kdf)) throw new Error("Unsupported kdf");
  if (!Number.isInteger(pack.iterations) || pack.iterations < 10000) throw new Error("Invalid iterations");
  if (!isB64(pack.salt)) throw new Error("Invalid salt");
  if (!isB64(pack.iv)) throw new Error("Invalid iv");
  if (!isB64(pack.data)) throw new Error("Invalid data");
  if (!isB64(pack.digest)) throw new Error("Invalid digest");
  if (typeof pack.kind !== "string" || !pack.kind) throw new Error("Invalid kind");
  if (pack.signature !== undefined) {
    if (!isObject(pack.signature)) throw new Error("Invalid signature envelope");
    if (pack.signature.alg !== "ECDSA-P256-SHA256") throw new Error("Unsupported signature alg");
    if (typeof pack.signature.keyId !== "string" || !pack.signature.keyId) throw new Error("Invalid signature keyId");
    if (!isB64(pack.signature.sig)) throw new Error("Invalid signature bytes");
  }
  return true;
}

export function normalizePack(pack) {
  if (!isObject(pack)) throw new Error("Pack must be an object");
  if (pack.format === "tear-v2") {
    validatePack(pack);
    return pack;
  }
  if (pack.format === "tear-v1") {
    const migrated = {
      format: "tear-v2",
      schemaVersion: 2,
      app: pack.app || "HyperSnatch",
      appVersion: "legacy-import",
      kind: pack.kind || "tear",
      createdAt: new Date().toISOString(),
      migratedFrom: "tear-v1",
      kdf: pack.kdf || "PBKDF2-SHA256",
      iterations: Number(pack.iterations || 120000),
      salt: pack.salt,
      iv: pack.iv,
      digest: pack.digest,
      data: pack.data
    };
    validatePack(migrated);
    return migrated;
  }
  throw new Error("Unknown pack format");
}
