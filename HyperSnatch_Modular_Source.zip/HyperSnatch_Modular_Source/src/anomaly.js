export function detectAnomalies(events) {
  const byType = new Map();
  for (const e of events || []) {
    byType.set(e.type, (byType.get(e.type) || 0) + 1);
  }
  const deferred = byType.get("deferred") || 0;
  const decoded = byType.get("decoded") || 0;
  const total = deferred + decoded;
  const deferRate = total ? deferred / total : 0;
  const findings = [];
  if (deferRate >= 0.7 && total >= 5) findings.push({ id: "high-defer-rate", severity: "high", deferRate });
  if ((byType.get("policy-airgapped") || 0) > 0 && decoded === 0 && deferred > 0) {
    findings.push({ id: "airgapped-blocking-throughput", severity: "medium" });
  }
  return { ok: findings.length === 0, findings };
}
