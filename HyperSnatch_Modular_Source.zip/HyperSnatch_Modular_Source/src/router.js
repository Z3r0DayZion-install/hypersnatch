const SUPPORTED = new Set(["emload.com", "kshared.com", "rapidgator.net"]);

export function detectHost(url) {
  try {
    return new URL(url).hostname.replace(/^www\./i, "").toLowerCase();
  } catch {
    return "";
  }
}

export function isSupportedHost(host) {
  return SUPPORTED.has(host);
}

export function gateHost(host, tier) {
  if (tier === "advanced") return { ok: true };
  if (host === "kshared.com" || host === "rapidgator.net") return { ok: false, reason: "Tier gate" };
  return { ok: true };
}
