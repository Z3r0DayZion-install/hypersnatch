const STRING_RX = /^[a-zA-Z0-9_-]+$/;
const B64_RX = /^[A-Za-z0-9+/]+={0,2}$/;
const HEX_RX = /^[a-fA-F0-9]+$/;
const VERSION_RX = /^\d+\.\d+\.\d+$/;

function isObject(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

function isArray(v) {
  return Array.isArray(v);
}

function isString(v) {
  return typeof v === "string";
}

function isNumber(v) {
  return typeof v === "number" && Number.isFinite(v);
}

function isBoolean(v) {
  return typeof v === "boolean";
}

function isB64(v) {
  return isString(v) && v.length > 0 && B64_RX.test(v);
}

function isHex(v) {
  return isString(v) && v.length > 0 && HEX_RX.test(v);
}

function isVersion(v) {
  return isString(v) && VERSION_RX.test(v);
}

function isAlphanumeric(v) {
  return isString(v) && STRING_RX.test(v);
}

export const SchemaType = {
  tearV2: "tear-v2",
  tearBundle: "hs-tear-bundle-1",
  releaseManifest: "hs-release-manifest-v1",
  trustStore: "hs-trust-store-v1",
  trustStoreV2: "hs-trust-store-v2",
  quarantineV2: "hs-quarantine-v2",
  doctorReport: "hs-doctor-report-v1",
  collectorPayload: "hs-collector-payload-v1"
};

export const ValidationError = class extends Error {
  constructor(message, path = []) {
    super(message);
    this.name = "ValidationError";
    this.path = path;
  }
};

export function validateTearV2Pack(pack, path = []) {
  const p = [...path, "tear-v2"];
  
  if (!isObject(pack)) throw new ValidationError(`Expected object, got ${typeof pack}`, p);
  if (pack.format !== "tear-v2") throw new ValidationError(`Expected format tear-v2, got ${pack.format}`, p);
  if (!isNumber(pack.schemaVersion)) throw new ValidationError("Missing or invalid schemaVersion", p);
  if (pack.schemaVersion !== 2) throw new ValidationError(`Unsupported schema version ${pack.schemaVersion}`, p);
  
  if (!isString(pack.app)) throw new ValidationError("Missing app field", p);
  if (!isVersion(pack.appVersion)) throw new ValidationError("Invalid appVersion format", p);
  if (!isAlphanumeric(pack.kind)) throw new ValidationError("Invalid kind field", p);
  if (!isString(pack.createdAt)) throw new ValidationError("Missing createdAt", p);
  
  if (!["PBKDF2-SHA256"].includes(pack.kdf)) throw new ValidationError(`Unsupported kdf: ${pack.kdf}`, p);
  if (!Number.isInteger(pack.iterations) || pack.iterations < 10000) throw new ValidationError("Invalid iterations", p);
  if (!isB64(pack.salt)) throw new ValidationError("Invalid salt (not base64)", p);
  if (!isB64(pack.iv)) throw new ValidationError("Invalid iv (not base64)", p);
  if (!isB64(pack.data)) throw new ValidationError("Invalid data (not base64)", p);
  if (!isB64(pack.digest)) throw new ValidationError("Invalid digest (not base64)", p);
  
  if (pack.signature !== undefined) {
    if (!isObject(pack.signature)) throw new ValidationError("Invalid signature envelope", p);
    if (pack.signature.alg !== "ECDSA-P256-SHA256") throw new ValidationError(`Unsupported signature alg: ${pack.signature.alg}`, p);
    if (!isString(pack.signature.keyId) || !pack.signature.keyId) throw new ValidationError("Invalid signature keyId", p);
    if (!isB64(pack.signature.sig)) throw new ValidationError("Invalid signature bytes", p);
  }
  
  if (pack.publicJwk !== undefined) {
    if (!isObject(pack.publicJwk)) throw new ValidationError("Invalid publicJwk", p);
  }
  
  return true;
}

export function validateTearBundle(bundle, path = []) {
  const p = [...path, "hs-tear-bundle-1"];
  
  if (!isObject(bundle)) throw new ValidationError(`Expected object, got ${typeof bundle}`, p);
  if (bundle.schema !== "hs-tear-bundle-1") throw new ValidationError(`Expected schema hs-tear-bundle-1, got ${bundle.schema}`, p);
  if (!isNumber(bundle.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (bundle.schemaVersion !== 1) throw new ValidationError(`Unsupported bundle version ${bundle.schemaVersion}`, p);
  
  if (!isString(bundle.app)) throw new ValidationError("Missing app field", p);
  if (!isVersion(bundle.appVersion)) throw new ValidationError("Invalid appVersion", p);
  if (!isString(bundle.createdAt)) throw new ValidationError("Missing createdAt", p);
  
  if (!isObject(bundle.manifest)) throw new ValidationError("Missing or invalid manifest", p);
  if (!isArray(bundle.manifest.entries)) throw new ValidationError("Missing manifest.entries array", p);
  
  for (let i = 0; i < bundle.manifest.entries.length; i++) {
    const entry = bundle.manifest.entries[i];
    const ep = [...p, "manifest.entries", i];
    if (!isString(entry.path)) throw new ValidationError("Missing entry.path", ep);
    if (!isString(entry.type)) throw new ValidationError("Missing entry.type", ep);
    if (!isNumber(entry.size)) throw new ValidationError("Missing entry.size", ep);
    if (!isHex(entry.sha256)) throw new ValidationError("Invalid entry.sha256", ep);
  }
  
  if (bundle.payload !== undefined) {
    if (!isObject(bundle.payload)) throw new ValidationError("Invalid payload", p);
    if (!isB64(bundle.payload.data)) throw new ValidationError("Invalid payload.data", p);
    if (!isB64(bundle.payload.digest)) throw new ValidationError("Invalid payload.digest", p);
  }
  
  return true;
}

export function validateReleaseManifest(manifest, path = []) {
  const p = [...path, "hs-release-manifest-v1"];
  
  if (!isObject(manifest)) throw new ValidationError(`Expected object, got ${typeof manifest}`, p);
  if (manifest.format !== "hs-release-manifest-v1") throw new ValidationError(`Expected format hs-release-manifest-v1`, p);
  if (!isString(manifest.createdAt)) throw new ValidationError("Missing createdAt", p);
  if (!isArray(manifest.items)) throw new ValidationError("Missing items array", p);
  
  for (let i = 0; i < manifest.items.length; i++) {
    const item = manifest.items[i];
    const ip = [...p, "items", i];
    if (!isString(item.path)) throw new ValidationError("Missing item.path", ip);
    if (!isNumber(item.bytes)) throw new ValidationError("Missing item.bytes", ip);
    if (!isHex(item.sha256)) throw new ValidationError("Invalid item.sha256", ip);
  }
  
  if (manifest.signature !== undefined) {
    if (!isObject(manifest.signature)) throw new ValidationError("Invalid signature", p);
    if (manifest.signature.alg !== "ECDSA-P256-SHA256") throw new ValidationError(`Unsupported sig alg: ${manifest.signature.alg}`, p);
    if (!isString(manifest.signature.keyId)) throw new ValidationError("Missing signature.keyId", p);
    if (!isB64(manifest.signature.sig)) throw new ValidationError("Invalid signature.sig", p);
  }
  
  return true;
}

export function validateTrustStore(store, path = []) {
  const p = [...path, "hs-trust-store-v1"];
  
  if (!isObject(store)) throw new ValidationError(`Expected object, got ${typeof store}`, p);
  if (store.format !== "hs-trust-store-v1") throw new ValidationError("Expected trust store format", p);
  if (!isNumber(store.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (!isArray(store.keys)) throw new ValidationError("Missing keys array", p);
  
  for (let i = 0; i < store.keys.length; i++) {
    const key = store.keys[i];
    const kp = [...p, "keys", i];
    if (!isString(key.id)) throw new ValidationError("Missing key.id", kp);
    if (!isString(key.label)) throw new ValidationError("Missing key.label", kp);
    if (!isObject(key.publicJwk)) throw new ValidationError("Missing key.publicJwk", kp);
    if (!isBoolean(key.revoked)) throw new ValidationError("Missing key.revoked boolean", kp);
    if (key.addedAt && !isString(key.addedAt)) throw new ValidationError("Invalid key.addedAt", kp);
  }
  
  return true;
}

export function validateQuarantine(q, path = []) {
  const p = [...path, "hs-quarantine-v1"];
  
  if (!isObject(q)) throw new ValidationError(`Expected object, got ${typeof q}`, p);
  if (q.format !== "hs-quarantine-v1") throw new ValidationError("Expected quarantine format", p);
  if (!isNumber(q.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (!isArray(q.entries)) throw new ValidationError("Missing entries array", p);
  
  for (let i = 0; i < q.entries.length; i++) {
    const entry = q.entries[i];
    const ep = [...p, "entries", i];
    if (!isString(entry.id)) throw new ValidationError("Missing entry.id", ep);
    if (!isString(entry.reason)) throw new ValidationError("Missing entry.reason", ep);
    if (!isString(entry.timestamp)) throw new ValidationError("Missing entry.timestamp", ep);
    if (entry.data !== undefined && !isString(entry.data)) throw new ValidationError("Invalid entry.data", ep);
  }
  
  return true;
}

export function validateTrustStoreV2(store, path = []) {
  const p = [...path, "hs-trust-store-v2"];
  
  if (!isObject(store)) throw new ValidationError(`Expected object, got ${typeof store}`, p);
  if (store.format !== "hs-trust-store-v2") throw new ValidationError("Expected trust store v2 format", p);
  if (!isNumber(store.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (!isArray(store.keys)) throw new ValidationError("Missing keys array", p);
  
  for (let i = 0; i < store.keys.length; i++) {
    const key = store.keys[i];
    const kp = [...p, "keys", i];
    if (!isString(key.id)) throw new ValidationError("Missing key.id", kp);
    if (!isString(key.label)) throw new ValidationError("Missing key.label", kp);
    if (!isObject(key.publicJwk)) throw new ValidationError("Missing key.publicJwk", kp);
    if (!isBoolean(key.revoked)) throw new ValidationError("Missing key.revoked boolean", kp);
    if (key.addedAt && !isString(key.addedAt)) throw new ValidationError("Invalid key.addedAt", kp);
    if (key.rotationCount !== undefined && !isNumber(key.rotationCount)) throw new ValidationError("Invalid key.rotationCount", kp);
  }
  
  if (store.policy !== undefined && !isObject(store.policy)) throw new ValidationError("Invalid policy", p);
  
  return true;
}

export function validateQuarantineV2(q, path = []) {
  const p = [...path, "hs-quarantine-v2"];
  
  if (!isObject(q)) throw new ValidationError(`Expected object, got ${typeof q}`, p);
  if (q.format !== "hs-quarantine-v2") throw new ValidationError("Expected quarantine v2 format", p);
  if (!isNumber(q.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (!isArray(q.entries)) throw new ValidationError("Missing entries array", p);
  
  for (let i = 0; i < q.entries.length; i++) {
    const entry = q.entries[i];
    const ep = [...p, "entries", i];
    if (!isString(entry.id)) throw new ValidationError("Missing entry.id", ep);
    if (!isString(entry.reason)) throw new ValidationError("Missing entry.reason", ep);
    if (!isString(entry.timestamp)) throw new ValidationError("Missing entry.timestamp", ep);
    if (entry.severity !== undefined && !isString(entry.severity)) throw new ValidationError("Invalid entry.severity", ep);
    if (entry.resolved !== undefined && !isBoolean(entry.resolved)) throw new ValidationError("Invalid entry.resolved", ep);
  }
  
  return true;
}

export function validateDoctorReport(report, path = []) {
  const p = [...path, "hs-doctor-report-v1"];
  
  if (!isObject(report)) throw new ValidationError(`Expected object, got ${typeof report}`, p);
  if (report.format !== "hs-doctor-report-v1") throw new ValidationError("Expected doctor report format", p);
  if (!isNumber(report.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (!isString(report.createdAt)) throw new ValidationError("Missing createdAt", p);
  if (!isString(report.app)) throw new ValidationError("Missing app", p);
  if (!isString(report.appVersion)) throw new ValidationError("Missing appVersion", p);
  if (!isArray(report.checks)) throw new ValidationError("Missing checks array", p);
  
  for (let i = 0; i < report.checks.length; i++) {
    const check = report.checks[i];
    const cp = [...p, "checks", i];
    if (!isString(check.name)) throw new ValidationError("Missing check.name", cp);
    if (!isString(check.status)) throw new ValidationError("Missing check.status", cp);
    if (check.details !== undefined && !isString(check.details)) throw new ValidationError("Invalid check.details", cp);
    if (check.durationMs !== undefined && !isNumber(check.durationMs)) throw new ValidationError("Invalid check.durationMs", cp);
  }
  
  if (report.signature !== undefined) {
    if (!isObject(report.signature)) throw new ValidationError("Invalid signature", p);
    if (!isB64(report.signature.sig)) throw new ValidationError("Invalid signature.sig", p);
    if (!isString(report.signature.keyId)) throw new ValidationError("Missing signature.keyId", p);
  }
  
  return true;
}

export function validateCollectorPayload(payload, path = []) {
  const p = [...path, "hs-collector-payload-v1"];
  
  if (!isObject(payload)) throw new ValidationError(`Expected object, got ${typeof payload}`, p);
  if (payload.format !== "hs-collector-payload-v1") throw new ValidationError("Expected collector payload format", p);
  if (!isNumber(payload.schemaVersion)) throw new ValidationError("Missing schemaVersion", p);
  if (!isString(payload.timestamp)) throw new ValidationError("Missing timestamp", p);
  if (!isArray(payload.links)) throw new ValidationError("Missing links array", p);
  if (!isObject(payload.fingerprint)) throw new ValidationError("Missing fingerprint", p);
  
  for (let i = 0; i < payload.links.length; i++) {
    const link = payload.links[i];
    const lp = [...p, "links", i];
    if (!isString(link.url)) throw new ValidationError("Missing link.url", lp);
  }
  
  return true;
}

export function validateSchema(pack, path = []) {
  if (!isObject(pack)) throw new ValidationError("Pack must be an object", path);
  
  const format = pack.format || pack.schema;
  
  switch (format) {
    case SchemaType.tearV2:
      return validateTearV2Pack(pack, path);
    case SchemaType.tearBundle:
      return validateTearBundle(pack, path);
    case SchemaType.releaseManifest:
      return validateReleaseManifest(pack, path);
    case SchemaType.trustStore:
      return validateTrustStore(pack, path);
    case SchemaType.trustStoreV2:
      return validateTrustStoreV2(pack, path);
    case SchemaType.quarantineV2:
      return validateQuarantineV2(pack, path);
    case SchemaType.doctorReport:
      return validateDoctorReport(pack, path);
    case SchemaType.collectorPayload:
      return validateCollectorPayload(pack, path);
    default:
      throw new ValidationError(`Unknown format: ${format}`, path);
  }
}

export function validateWithErrors(pack) {
  const errors = [];
  try {
    validateSchema(pack);
  } catch (e) {
    if (e instanceof ValidationError) {
      errors.push({ message: e.message, path: e.path });
    } else {
      errors.push({ message: e.message, path: [] });
    }
  }
  return { valid: errors.length === 0, errors };
}

export function getSchemaType(pack) {
  if (!isObject(pack)) return null;
  return pack.format || pack.schema || null;
}
