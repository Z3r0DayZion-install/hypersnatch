export const RuleTestSandbox = {
  container: null,
  onResult: null,
  
  init(containerId, onResult) {
    this.container = document.getElementById(containerId);
    this.onResult = onResult;
    
    if (this.container) {
      this.render();
    }
  },
  
  render() {
    this.container.innerHTML = `
      <div class="sandbox-panel">
        <div class="panel-header">
          <h3>🧪 Rule Test Sandbox</h3>
        </div>
        
        <div class="sandbox-layout">
          <div class="sandbox-input">
            <h4>Test Input</h4>
            <div class="form-group">
              <label>HTML Snippet</label>
              <textarea id="test-html" class="form-control code" rows="8" placeholder="<div>...</div>"></textarea>
            </div>
            <div class="form-group">
              <label>URL (optional)</label>
              <input type="text" id="test-url" class="form-control" placeholder="https://example.com/file">
            </div>
          </div>
          
          <div class="sandbox-rules">
            <h4>Test Rules</h4>
            <div class="rule-selector">
              <label>Select Rules to Test:</label>
              <div class="checkbox-group">
                <label><input type="checkbox" value="extract-links" checked> Extract Links</label>
                <label><input type="checkbox" value="extract-metadata" checked> Extract Metadata</label>
                <label><input type="checkbox" value="extract-download"> Extract Download URL</label>
                <label><input type="checkbox" value="validate-structure"> Validate Structure</label>
                <label><input type="checkbox" value="detect-host"> Detect Host</label>
              </div>
            </div>
          </div>
          
          <div class="sandbox-actions">
            <button class="btn-run-test" data-action="run">▶ Run Test</button>
            <button class="btn-clear" data-action="clear">Clear</button>
            <button class="btn-load-sample" data-action="sample">Load Sample</button>
          </div>
          
          <div class="sandbox-output">
            <h4>Test Results</h4>
            <div id="test-results" class="results-panel">
              <div class="empty-state">Run a test to see results</div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    this.attachEvents();
  },
  
  attachEvents() {
    this.container.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const action = e.target.dataset.action;
        this.handleAction(action);
      });
    });
  },
  
  handleAction(action) {
    switch (action) {
      case "run":
        this.runTest();
        break;
      case "clear":
        this.clear();
        break;
      case "sample":
        this.loadSample();
        break;
    }
  },
  
  getSelectedRules() {
    const checkboxes = this.container.querySelectorAll(".checkbox-group input:checked");
    return Array.from(checkboxes).map(cb => cb.value);
  },
  
  async runTest() {
    const html = document.getElementById("test-html").value;
    const url = document.getElementById("test-url").value;
    const rules = this.getSelectedRules();
    
    if (!html) {
      alert("Please enter HTML to test");
      return;
    }
    
    const results = {
      timestamp: new Date().toISOString(),
      rules: {},
      success: true,
      errors: []
    };
    
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    
    for (const rule of rules) {
      try {
        const result = await this.runRule(rule, doc, url);
        results.rules[rule] = result;
      } catch (e) {
        results.rules[rule] = { error: e.message };
        results.errors.push({ rule, error: e.message });
      }
    }
    
    results.success = results.errors.length === 0;
    
    this.displayResults(results);
    
    if (this.onResult) this.onResult(results);
  },
  
  async runRule(rule, doc, url) {
    switch (rule) {
      case "extract-links":
        return this.testExtractLinks(doc);
      case "extract-metadata":
        return this.testExtractMetadata(doc);
      case "extract-download":
        return this.testExtractDownload(url, doc);
      case "validate-structure":
        return this.testValidateStructure(doc);
      case "detect-host":
        return this.testDetectHost(url);
      default:
        throw new Error(`Unknown rule: ${rule}`);
    }
  },
  
  testExtractLinks(doc) {
    const links = Array.from(doc.querySelectorAll("a[href]")).map(a => ({
      text: a.textContent?.trim().slice(0, 50),
      href: a.href,
      rel: a.rel
    }));
    
    return {
      count: links.length,
      links: links.slice(0, 10),
      hasExternal: links.some(l => l.href.startsWith("http"))
    };
  },
  
  testExtractMetadata(doc) {
    const meta = {};
    
    const ogTitle = doc.querySelector('meta[property="og:title"]');
    if (ogTitle) meta.ogTitle = ogTitle.content;
    
    const ogDesc = doc.querySelector('meta[property="og:description"]');
    if (ogDesc) meta.ogDescription = ogDesc.content;
    
    const ogImage = doc.querySelector('meta[property="og:image"]');
    if (ogImage) meta.ogImage = ogImage.content;
    
    const title = doc.querySelector("title");
    if (title) meta.title = title.textContent;
    
    const desc = doc.querySelector('meta[name="description"]');
    if (desc) meta.description = desc.content;
    
    return {
      found: Object.keys(meta).length,
      metadata: meta
    };
  },
  
  testExtractDownload(url, doc) {
    const results = { url };
    
    const downloadBtn = doc.querySelector("[class*='download'], [id*='download'], .btn-download");
    if (downloadBtn) {
      results.downloadButton = {
        text: downloadBtn.textContent?.trim(),
        href: downloadBtn.href
      };
    }
    
    const directLink = doc.querySelector("a[href*='download'], a[href*='file'], a[href$='.zip'], a[href$='.rar']");
    if (directLink) {
      results.directLink = directLink.href;
    }
    
    const scripts = Array.from(doc.querySelectorAll("script")).map(s => s.textContent);
    const downloadPattern = scripts.find(s => s.includes("download") || s.includes("file"));
    if (downloadPattern) {
      results.scriptFound = true;
    }
    
    return results;
  },
  
  testValidateStructure(doc) {
    const issues = [];
    
    const forms = doc.querySelectorAll("form");
    if (forms.length > 0) {
      issues.push({ type: "info", message: `${forms.length} form(s) found` });
    }
    
    const iframes = doc.querySelectorAll("iframe");
    if (iframes.length > 0) {
      issues.push({ type: "warning", message: `${iframes.length} iframe(s) found` });
    }
    
    const scripts = doc.querySelectorAll("script");
    if (scripts.length > 10) {
      issues.push({ type: "warning", message: `${scripts.length} scripts - potential complexity` });
    }
    
    const images = doc.querySelectorAll("img");
    const brokenImages = Array.from(images).filter(img => !img.complete);
    if (brokenImages.length > 0) {
      issues.push({ type: "info", message: `${brokenImages.length} potentially broken images` });
    }
    
    return {
      valid: true,
      issues,
      stats: {
        forms: forms.length,
        scripts: scripts.length,
        images: images.length,
        links: doc.querySelectorAll("a").length
      }
    };
  },
  
  testDetectHost(url) {
    if (!url) {
      return { error: "No URL provided" };
    }
    
    try {
      const urlObj = new URL(url);
      const hostname = urlObj.hostname;
      
      const patterns = {
        emload: /emload\.com/i,
        kshared: /kshared\.com/i,
        rapidgator: /rapidgator\.net/i,
        google: /drive\.google\.com|docs\.google\.com/i,
        dropbox: /dropbox\.com/i,
        mega: /mega\.nz/i
      };
      
      const detected = [];
      for (const [host, pattern] of Object.entries(patterns)) {
        if (pattern.test(hostname)) {
          detected.push(host);
        }
      }
      
      return {
        hostname,
        protocol: urlObj.protocol,
        path: urlObj.pathname,
        detectedHosts: detected,
        isSupported: detected.some(h => ["emload", "kshared", "rapidgator"].includes(h))
      };
    } catch (e) {
      return { error: `Invalid URL: ${e.message}` };
    }
  },
  
  displayResults(results) {
    const panel = document.getElementById("test-results");
    
    let html = `
      <div class="result-header ${results.success ? "success" : "error"}">
        <span class="status">${results.success ? "✓ All tests passed" : "✗ Some tests failed"}</span>
        <span class="timestamp">${results.timestamp}</span>
      </div>
    `;
    
    for (const [rule, result] of Object.entries(results.rules)) {
      html += `
        <div class="rule-result">
          <div class="rule-header">
            <span class="rule-name">${rule}</span>
            <span class="rule-status ${result.error ? "error" : "pass"}">
              ${result.error ? "✗ Error" : "✓ Pass"}
            </span>
          </div>
          <pre class="rule-output">${this.escapeHtml(JSON.stringify(result, null, 2))}</pre>
        </div>
      `;
    }
    
    panel.innerHTML = html;
  },
  
  clear() {
    document.getElementById("test-html").value = "";
    document.getElementById("test-url").value = "";
    document.getElementById("test-results").innerHTML = '<div class="empty-state">Run a test to see results</div>';
  },
  
  loadSample() {
    const sample = `<!DOCTYPE html>
<html>
<head>
  <title>Sample Download Page</title>
  <meta property="og:title" content="Sample File">
  <meta property="og:description" content="Download this file">
</head>
<body>
  <h1>File Download</h1>
  <p>Click below to download:</p>
  <a href="https://example.com/download/file123" class="btn-download" rel="nofollow">
    Download File
  </a>
  <a href="https://emload.com/file/abc123">emload link</a>
  <a href="https://kshared.com/folder/xyz">KShared folder</a>
  <script>const downloadUrl = "https://example.com/api/download";</script>
</body>
</html>`;
    
    document.getElementById("test-html").value = sample;
    document.getElementById("test-url").value = "https://example.com/download/page";
  },
  
  escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
};

export function attachSandbox(containerId, onResult) {
  return RuleTestSandbox.init(containerId, onResult);
}
