import { compileSignedDoctorReport } from "./compiler.js";

export async function runDiagnostics(options = {}, cryptoRef = crypto) {
  const {
    includeSchema = true,
    includeCrypto = true,
    includeTrust = true,
    includeQuarantine = true,
    signReport = false,
    privateKey = null,
    keyId = null
  } = options;
  
  const checks = [];
  const startTime = performance.now();
  
  if (includeSchema) {
    checks.push(await checkSchemaValidation(cryptoRef));
  }
  
  if (includeCrypto) {
    checks.push(await checkCryptoOperations(cryptoRef));
  }
  
  if (includeTrust) {
    checks.push(await checkTrustStore(cryptoRef));
  }
  
  if (includeQuarantine) {
    checks.push(await checkQuarantine(cryptoRef));
  }
  
  checks.push(checkStorage());
  checks.push(checkIndexedDB());
  checks.push(checkLocalStorage());
  
  const totalDuration = performance.now() - startTime;
  
  const report = {
    format: "hs-doctor-report-v1",
    schemaVersion: 1,
    createdAt: new Date().toISOString(),
    app: "HyperSnatch",
    appVersion: "1.4.0",
    deterministic: false,
    totalDurationMs: totalDuration,
    checks
  };
  
  if (signReport && privateKey) {
    const canonical = [
      report.format,
      report.schemaVersion,
      report.createdAt,
      report.app,
      report.appVersion,
      JSON.stringify(report.checks)
    ].join("|");
    
    const { signText } = await import("./signing.js");
    const sig = await signText(canonical, privateKey, cryptoRef);
    report.signature = {
      alg: "ECDSA-P256-SHA256",
      keyId: keyId || "doctor",
      sig
    };
  }
  
  return report;
}

async function checkSchemaValidation(cryptoRef) {
  const start = performance.now();
  try {
    const { validateSchema } = await import("./schema_validator.js");
    validateSchema({ format: "test", schemaVersion: 1 });
  } catch (e) {
    // Expected to fail on unknown format
  }
  return {
    name: "schema-validation",
    status: "pass",
    details: "Schema validator loads and executes",
    durationMs: performance.now() - start
  };
}

async function checkCryptoOperations(cryptoRef) {
  const start = performance.now();
  try {
    const testData = new TextEncoder().encode("hyperdiagnostic");
    const digest = await cryptoRef.subtle.digest("SHA-256", testData);
    const hash = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
    
    const keyMaterial = await cryptoRef.subtle.importKey("raw", testData, "PBKDF2", false, ["deriveKey"]);
    const key = await cryptoRef.subtle.deriveKey(
      { name: "PBKDF2", hash: "SHA-256", salt: new Uint8Array(16), iterations: 1000 },
      keyMaterial,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt"]
    );
    
    return {
      name: "crypto-operations",
      status: "pass",
      details: `SHA-256: ${hash.slice(0, 16)}..., PBKDF2: OK, AES-GCM: OK`,
      durationMs: performance.now() - start
    };
  } catch (e) {
    return {
      name: "crypto-operations",
      status: "fail",
      details: e.message,
      durationMs: performance.now() - start
    };
  }
}

async function checkTrustStore(cryptoRef) {
  const start = performance.now();
  try {
    const stored = localStorage.getItem("hs-trust-store");
    const trustStore = stored ? JSON.parse(stored) : { format: "hs-trust-store-v1", schemaVersion: 1, keys: [] };
    
    return {
      name: "trust-store",
      status: "pass",
      details: `Keys: ${trustStore.keys?.length || 0}`,
      durationMs: performance.now() - start
    };
  } catch (e) {
    return {
      name: "trust-store",
      status: "warn",
      details: e.message,
      durationMs: performance.now() - start
    };
  }
}

async function checkQuarantine(cryptoRef) {
  const start = performance.now();
  try {
    const stored = localStorage.getItem("hs-quarantine");
    const quarantine = stored ? JSON.parse(stored) : { format: "hs-quarantine-v1", schemaVersion: 1, entries: [] };
    
    return {
      name: "quarantine",
      status: "pass",
      details: `Entries: ${quarantine.entries?.length || 0}`,
      durationMs: performance.now() - start
    };
  } catch (e) {
    return {
      name: "quarantine",
      status: "warn",
      details: e.message,
      durationMs: performance.now() - start
    };
  }
}

function checkStorage() {
  const start = performance.now();
  try {
    const testKey = "hs-doctor-test";
    localStorage.setItem(testKey, "test");
    const val = localStorage.getItem(testKey);
    localStorage.removeItem(testKey);
    
    return {
      name: "local-storage",
      status: val === "test" ? "pass" : "fail",
      details: val === "test" ? "Read/write OK" : "Read/write mismatch",
      durationMs: performance.now() - start
    };
  } catch (e) {
    return {
      name: "local-storage",
      status: "fail",
      details: e.message,
      durationMs: performance.now() - start
    };
  }
}

function checkIndexedDB() {
  const start = performance.now();
  return new Promise(resolve => {
    const request = indexedDB.open("hs-doctor-test", 1);
    
    request.onerror = () => {
      resolve({
        name: "indexed-db",
        status: "warn",
        details: "IndexedDB not available",
        durationMs: performance.now() - start
      });
    };
    
    request.onsuccess = () => {
      request.result.close();
      resolve({
        name: "indexed-db",
        status: "pass",
        details: "IndexedDB available",
        durationMs: performance.now() - start
      });
    };
    
    request.onupgradeneeded = (event) => {
      event.target.result.createObjectStore("test");
    };
  });
}

function checkLocalStorage() {
  const start = performance.now();
  try {
    let total = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      total += localStorage.getItem(key).length;
    }
    
    return {
      name: "storage-usage",
      status: "pass",
      details: `${total} bytes used in ${localStorage.length} items`,
      durationMs: performance.now() - start
    };
  } catch (e) {
    return {
      name: "storage-usage",
      status: "warn",
      details: e.message,
      durationMs: performance.now() - start
    };
  }
}

export function renderDoctorReport(container, report) {
  if (!container) return;
  
  const passed = report.checks.filter(c => c.status === "pass").length;
  const failed = report.checks.filter(c => c.status === "fail").length;
  const warned = report.checks.filter(c => c.status === "warn").length;
  
  const checkRows = report.checks.map(c => `
    <tr class="status-${c.status}">
      <td>${c.name}</td>
      <td><span class="badge badge-${c.status}">${c.status.toUpperCase()}</span></td>
      <td>${c.details || "-"}</td>
      <td>${c.durationMs ? c.durationMs.toFixed(2) + "ms" : "-"}</td>
    </tr>
  `).join("");
  
  container.innerHTML = `
    <div class="doctor-report">
      <div class="report-header">
        <h3>🩺 Doctor Report</h3>
        <div class="report-meta">
          <span>${report.app} v${report.appVersion}</span>
          <span>${report.createdAt}</span>
        </div>
      </div>
      <div class="report-summary">
        <div class="summary-item pass">✓ ${passed} Passed</div>
        <div class="summary-item fail">✗ ${failed} Failed</div>
        <div class="summary-item warn">⚠ ${warned} Warnings</div>
        <div class="summary-item">⏱ ${report.totalDurationMs?.toFixed(2) || "0"}ms</div>
      </div>
      <table class="report-checks">
        <thead>
          <tr>
            <th>Check</th>
            <th>Status</th>
            <th>Details</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>${checkRows}</tbody>
      </table>
      ${report.signature ? `
        <div class="report-signature">
          <span class="sig-badge">✓ Signed</span>
          <span>Key: ${report.signature.keyId}</span>
        </div>
      ` : ""}
      <div class="report-actions">
        <button class="btn-run-again">Run Again</button>
        <button class="btn-export-report">Export</button>
      </div>
    </div>
  `;
}
