export const POLICY_TEMPLATES = {
  regulated: {
    profile: "strict",
    airgapped: true,
    requireSignedImport: true,
    tofu: false
  },
  enterprise: {
    profile: "balanced",
    airgapped: false,
    requireSignedImport: true,
    tofu: false
  },
  lab: {
    profile: "aggressive",
    airgapped: false,
    requireSignedImport: false,
    tofu: true
  }
};

export function applyPolicyTemplate(target, templateName) {
  const tpl = POLICY_TEMPLATES[templateName];
  if (!tpl) throw new Error("Unknown template");
  Object.assign(target, tpl);
  return target;
}
