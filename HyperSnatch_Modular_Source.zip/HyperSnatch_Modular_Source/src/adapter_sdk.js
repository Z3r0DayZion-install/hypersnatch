export const AdapterError = {
  INVALID_INPUT: "ADAPTER_INVALID_INPUT",
  NETWORK_ERROR: "ADAPTER_NETWORK_ERROR",
  PARSE_ERROR: "ADAPTER_PARSE_ERROR",
  TIMEOUT: "ADAPTER_TIMEOUT",
  RATE_LIMITED: "ADAPTER_RATE_LIMITED",
  NOT_SUPPORTED: "ADAPTER_NOT_SUPPORTED"
};

export class AdapterSDK {
  constructor(options = {}) {
    this.name = options.name || "unnamed";
    this.version = options.version || "1.0.0";
    this.rules = options.rules || [];
    this.enabled = true;
  }
  
  register() {
    AdapterRegistry.register(this);
    return this;
  }
  
  unregister() {
    AdapterRegistry.unregister(this.name);
    return this;
  }
  
  canHandle(url) {
    return this.rules.some(rule => {
      if (typeof rule === "string") {
        return url.includes(rule);
      }
      if (rule instanceof RegExp) {
        return rule.test(url);
      }
      if (typeof rule === "function") {
        return rule(url);
      }
      return false;
    });
  }
  
  async execute(url, context = {}) {
    if (!this.enabled) {
      throw new Error(`Adapter ${this.name} is disabled`);
    }
    
    if (!this.canHandle(url)) {
      throw new Error(`Adapter ${this.name} cannot handle this URL`);
    }
    
    return this.onExecute(url, context);
  }
  
  onExecute(url, context) {
    throw new Error("Adapter must implement onExecute");
  }
  
  setEnabled(enabled) {
    this.enabled = enabled;
    return this;
  }
  
  getMetadata() {
    return {
      name: this.name,
      version: this.version,
      enabled: this.enabled,
      rules: this.rules.map(r => r.toString())
    };
  }
}

export const AdapterRegistry = {
  adapters: new Map(),
  
  register(adapter) {
    if (!(adapter instanceof AdapterSDK)) {
      throw new Error("Must be an AdapterSDK instance");
    }
    this.adapters.set(adapter.name, adapter);
    return this;
  },
  
  unregister(name) {
    this.adapters.delete(name);
    return this;
  },
  
  get(name) {
    return this.adapters.get(name);
  },
  
  getAll() {
    return Array.from(this.adapters.values());
  },
  
  findForUrl(url) {
    for (const adapter of this.adapters.values()) {
      if (adapter.enabled && adapter.canHandle(url)) {
        return adapter;
      }
    }
    return null;
  },
  
  async execute(url, context = {}) {
    const adapter = this.findForUrl(url);
    
    if (!adapter) {
      throw new Error(`No adapter found for URL: ${url}`);
    }
    
    return adapter.execute(url, context);
  },
  
  clear() {
    this.adapters.clear();
    return this;
  },
  
  getMetadata() {
    return this.getAll().map(a => a.getMetadata());
  }
};

export function createAdapter(config) {
  class CustomAdapter extends AdapterSDK {
    constructor() {
      super(config);
    }
    
    onExecute(url, context) {
      if (config.execute) {
        return config.execute(url, context);
      }
      throw new Error("No execute handler defined");
    }
  }
  
  return new CustomAdapter();
}

export function createDataOnlyAdapter(name, handler) {
  return createAdapter({
    name,
    version: "1.0.0",
    rules: [],
    execute: async (url, context) => {
      const result = await handler(url, context);
      
      if (result && typeof result === "object") {
        if (result._unsafe_execute) {
          console.warn("Adapter returned executable code - data-only rulepack violation");
        }
      }
      
      return {
        url,
        adapter: name,
        timestamp: new Date().toISOString(),
        data: result
      };
    }
  });
}

export const AdapterSandbox = {
  context: {},
  
  setContext(ctx) {
    this.context = { ...this.context, ...ctx };
  },
  
  getContext() {
    return { ...this.context };
  },
  
  clearContext() {
    this.context = {};
  }
};

export function createRulepack(name, rules, options = {}) {
  return {
    name,
    version: options.version || "1.0.0",
    description: options.description || "",
    adapter: options.adapter || null,
    rules,
    metadata: {
      createdAt: new Date().toISOString(),
      author: options.author || "unknown",
      tags: options.tags || []
    }
  };
}

export function validateRulepack(rulepack) {
  const errors = [];
  
  if (!rulepack.name) errors.push("Missing name");
  if (!rulepack.rules || !Array.isArray(rulepack.rules)) {
    errors.push("Missing or invalid rules array");
  }
  
  for (let i = 0; i < rulepack.rules.length; i++) {
    const rule = rulepack.rules[i];
    
    if (!rule.pattern && !rule.host) {
      errors.push(`Rule ${i}: missing pattern or host`);
    }
    
    if (rule.type === "extract" && !rule.field) {
      errors.push(`Rule ${i}: extract rule missing field`);
    }
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}
