export const RevocationUI = {
  container: null,
  quarantine: null,
  trustStore: null,
  onUpdate: null,
  
  init(containerId, quarantine, trustStore, onUpdate) {
    this.container = document.getElementById(containerId);
    this.quarantine = quarantine;
    this.trustStore = trustStore;
    this.onUpdate = onUpdate;
    
    if (this.container) {
      this.render();
    }
  },
  
  render() {
    if (!this.container) return;
    
    const entries = this.quarantine?.entries || [];
    const pending = entries.filter(e => !e.resolved);
    const resolved = entries.filter(e => e.resolved);
    
    this.container.innerHTML = `
      <div class="revocation-panel">
        <div class="panel-header">
          <h3>🛡️ Quarantine & Revocation</h3>
          <button class="btn-add-entry" data-action="add">+ Add Entry</button>
        </div>
        
        <div class="stats-bar">
          <div class="stat">
            <span class="stat-value">${pending.length}</span>
            <span class="stat-label">Pending</span>
          </div>
          <div class="stat">
            <span class="stat-value">${resolved.length}</span>
            <span class="stat-label">Resolved</span>
          </div>
          <div class="stat">
            <span class="stat-value">${this.getRevokedKeyCount()}</span>
            <span class="stat-label">Revoked Keys</span>
          </div>
        </div>
        
        <div class="workflow-tabs">
          <button class="tab active" data-tab="quarantine">Quarantine Queue</button>
          <button class="tab" data-tab="revocation-log">Revocation Log</button>
        </div>
        
        <div class="tab-content active" id="tab-quarantine">
          ${this.renderQuarantineList(pending)}
        </div>
        
        <div class="tab-content" id="tab-revocation-log">
          ${this.renderRevocationLog()}
        </div>
        
        ${this.renderEntryModal()}
        ${this.renderDetailsModal()}
      </div>
    `;
    
    this.attachEvents();
  },
  
  getRevokedKeyCount() {
    return (this.trustStore?.keys || []).filter(k => k.revoked).length;
  },
  
  renderQuarantineList(entries) {
    if (entries.length === 0) {
      return `<div class="empty-state">No pending quarantine entries</div>`;
    }
    
    return entries.map(entry => `
      <div class="quarantine-card" data-entry-id="${entry.id}">
        <div class="card-header">
          <span class="severity-badge ${entry.severity || "medium"}">${entry.severity || "medium"}</span>
          <span class="entry-id">${this.escapeHtml(entry.id.slice(0, 12))}...</span>
          <span class="timestamp">${entry.timestamp}</span>
        </div>
        <div class="card-body">
          <p class="reason">${this.escapeHtml(entry.reason)}</p>
          ${entry.data ? `<pre class="entry-data">${this.escapeHtml(entry.data.slice(0, 200))}...</pre>` : ""}
        </div>
        <div class="card-actions">
          <button class="btn-release" data-action="release" data-entry-id="${entry.id}">✓ Release</button>
          <button class="btn-details" data-action="details" data-entry-id="${entry.id}">🔍 Details</button>
          <button class="btn-permanent-revoke" data-action="permanent-revoke" data-entry-id="${entry.id}">🚫 Permanent Revoke</button>
        </div>
      </div>
    `).join("");
  },
  
  renderRevocationLog() {
    const revokedKeys = (this.trustStore?.keys || []).filter(k => k.revoked);
    
    if (revokedKeys.length === 0) {
      return `<div class="empty-state">No revoked keys</div>`;
    }
    
    return revokedKeys.map(key => `
      <div class="revocation-card">
        <div class="card-header">
          <span class="status-badge revoked">REVOKED</span>
          <span class="key-id">${this.escapeHtml(key.id)}</span>
        </div>
        <div class="card-body">
          <p><strong>Label:</strong> ${this.escapeHtml(key.label)}</p>
          <p><strong>Revoked:</strong> ${key.revokedAt || key.lastRotated || "Unknown"}</p>
          <p><strong>Rotations:</strong> ${key.rotationCount || 0}</p>
        </div>
        <div class="card-actions">
          <button class="btn-restore-key" data-action="restore-key" data-key-id="${key.id}">↩ Restore Key</button>
          <button class="btn-export-key" data-action="export-revoked" data-key-id="${key.id}">↑ Export</button>
        </div>
      </div>
    `).join("");
  },
  
  renderEntryModal() {
    return `
      <div class="modal-overlay" id="entry-modal" style="display: none;">
        <div class="modal">
          <div class="modal-header">
            <h4>Add Quarantine Entry</h4>
            <button class="modal-close" data-action="close-entry-modal">×</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>Entry ID</label>
              <input type="text" id="entry-id" class="form-control" placeholder="unique-entry-id">
            </div>
            <div class="form-group">
              <label>Reason</label>
              <textarea id="entry-reason" class="form-control" rows="3" placeholder="Reason for quarantine..."></textarea>
            </div>
            <div class="form-group">
              <label>Severity</label>
              <select id="entry-severity" class="form-control">
                <option value="low">Low</option>
                <option value="medium" selected>Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
            <div class="form-group">
              <label>Additional Data (JSON)</label>
              <textarea id="entry-data" class="form-control" rows="3" placeholder='{"key": "value"}'></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" data-action="close-entry-modal">Cancel</button>
            <button class="btn-confirm-add" data-action="confirm-add">Add to Quarantine</button>
          </div>
        </div>
      </div>
    `;
  },
  
  renderDetailsModal() {
    return `
      <div class="modal-overlay" id="details-modal" style="display: none;">
        <div class="modal modal-lg">
          <div class="modal-header">
            <h4>Entry Details</h4>
            <button class="modal-close" data-action="close-details-modal">×</button>
          </div>
          <div class="modal-body" id="details-content">
          </div>
          <div class="modal-footer">
            <button class="btn-cancel" data-action="close-details-modal">Close</button>
          </div>
        </div>
      </div>
    `;
  },
  
  attachEvents() {
    const panel = this.container;
    
    panel.querySelectorAll(".tab").forEach(tab => {
      tab.addEventListener("click", (e) => this.switchTab(e.target.dataset.tab));
    });
    
    panel.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const action = e.target.dataset.action;
        const id = e.target.dataset.entryId || e.target.dataset.keyId;
        this.handleAction(action, id);
      });
    });
  },
  
  switchTab(tabName) {
    this.container.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    this.container.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    
    this.container.querySelector(`[data-tab="${tabName}"]`).classList.add("active");
    this.container.querySelector(`#tab-${tabName}`).classList.add("active");
  },
  
  handleAction(action, id) {
    switch (action) {
      case "add":
        this.showModal("entry-modal");
        break;
      case "confirm-add":
        this.addEntry();
        break;
      case "close-entry-modal":
        this.hideModal("entry-modal");
        break;
      case "close-details-modal":
        this.hideModal("details-modal");
        break;
      case "release":
        this.releaseEntry(id);
        break;
      case "details":
        this.showDetails(id);
        break;
      case "permanent-revoke":
        this.permanentRevoke(id);
        break;
      case "restore-key":
        this.restoreKey(id);
        break;
      case "export-revoked":
        this.exportRevokedKey(id);
        break;
    }
  },
  
  addEntry() {
    const id = document.getElementById("entry-id").value || `entry-${Date.now()}`;
    const reason = document.getElementById("entry-reason").value;
    const severity = document.getElementById("entry-severity").value;
    const dataStr = document.getElementById("entry-data").value;
    
    if (!reason) {
      alert("Please provide a reason");
      return;
    }
    
    const entry = {
      id,
      reason,
      severity,
      timestamp: new Date().toISOString(),
      resolved: false,
      data: dataStr || undefined
    };
    
    if (!this.quarantine) {
      this.quarantine = {
        format: "hs-quarantine-v2",
        schemaVersion: 2,
        entries: []
      };
    }
    
    this.quarantine.entries.push(entry);
    this.saveQuarantine();
    this.hideModal("entry-modal");
    this.render();
    
    if (this.onUpdate) this.onUpdate(this.quarantine);
  },
  
  releaseEntry(id) {
    const entry = this.quarantine?.entries.find(e => e.id === id);
    if (entry) {
      entry.resolved = true;
      entry.resolvedAt = new Date().toISOString();
      entry.resolution = "released";
      this.saveQuarantine();
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.quarantine);
    }
  },
  
  showDetails(id) {
    const entry = this.quarantine?.entries.find(e => e.id === id);
    if (!entry) return;
    
    const content = document.getElementById("details-content");
    content.innerHTML = `
      <div class="details-grid">
        <div class="detail-row">
          <span class="detail-label">ID:</span>
          <span class="detail-value">${this.escapeHtml(entry.id)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Severity:</span>
          <span class="severity-badge ${entry.severity || "medium"}">${entry.severity || "medium"}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Timestamp:</span>
          <span class="detail-value">${entry.timestamp}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Resolved:</span>
          <span class="detail-value">${entry.resolved ? "Yes (" + (entry.resolvedAt || "") + ")" : "No"}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Reason:</span>
          <span class="detail-value">${this.escapeHtml(entry.reason)}</span>
        </div>
        ${entry.data ? `
          <div class="detail-row full">
            <span class="detail-label">Data:</span>
            <pre class="detail-value">${this.escapeHtml(JSON.stringify(entry.data, null, 2))}</pre>
          </div>
        ` : ""}
      </div>
    `;
    
    this.showModal("details-modal");
  },
  
  permanentRevoke(id) {
    if (!confirm("This will permanently revoke the associated key. Continue?")) {
      return;
    }
    
    const entry = this.quarantine?.entries.find(e => e.id === id);
    if (entry) {
      entry.resolved = true;
      entry.resolvedAt = new Date().toISOString();
      entry.resolution = "permanent-revoke";
      
      const keyId = entry.keyId || id.replace("entry-", "key-");
      const key = this.trustStore?.keys?.find(k => k.id === keyId);
      if (key) {
        key.revoked = true;
        key.revokedAt = new Date().toISOString();
        this.saveTrustStore();
      }
      
      this.saveQuarantine();
      this.render();
      
      if (this.onUpdate) {
        this.onUpdate(this.quarantine, this.trustStore);
      }
    }
  },
  
  restoreKey(keyId) {
    const key = this.trustStore?.keys?.find(k => k.id === keyId);
    if (key) {
      key.revoked = false;
      key.restoredAt = new Date().toISOString();
      delete key.revokedAt;
      this.saveTrustStore();
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.quarantine, this.trustStore);
    }
  },
  
  exportRevokedKey(keyId) {
    const key = this.trustStore?.keys?.find(k => k.id === keyId);
    if (!key) return;
    
    const exportData = {
      id: key.id,
      label: key.label,
      publicJwk: key.publicJwk,
      revoked: true,
      revokedAt: key.revokedAt,
      rotationCount: key.rotationCount
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `revoked-key-${keyId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  },
  
  saveQuarantine() {
    if (this.quarantine) {
      localStorage.setItem("hs-quarantine", JSON.stringify(this.quarantine));
    }
  },
  
  saveTrustStore() {
    if (this.trustStore) {
      localStorage.setItem("hs-trust-store", JSON.stringify(this.trustStore));
    }
  },
  
  showModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = "flex";
  },
  
  hideModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = "none";
  },
  
  escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
};

export function attachRevocationUI(containerId, quarantine, trustStore, onUpdate) {
  return RevocationUI.init(containerId, quarantine, trustStore, onUpdate);
}
