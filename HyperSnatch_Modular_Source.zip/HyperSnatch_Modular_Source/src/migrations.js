import { validateSchema, ValidationError } from "./schema_validator.js";

export const Migrations = {
  "tear-v1": {
    toTearV2: (pack) => {
      if (pack.format !== "tear-v1") {
        throw new ValidationError("Not a tear-v1 pack");
      }
      
      return {
        format: "tear-v2",
        schemaVersion: 2,
        app: pack.app || "HyperSnatch",
        appVersion: pack.appVersion || "1.0.0",
        kind: pack.kind || "tear",
        createdAt: pack.createdAt || new Date().toISOString(),
        migratedFrom: "tear-v1",
        kdf: pack.kdf || "PBKDF2-SHA256",
        iterations: Number(pack.iterations || 120000),
        salt: pack.salt,
        iv: pack.iv,
        digest: pack.digest,
        data: pack.data
      };
    }
  },
  
  "hs-trust-store-v1": {
    toV2: (store) => {
      if (store.format !== "hs-trust-store-v1") {
        throw new ValidationError("Not a trust store v1");
      }
      
      const migrated = {
        format: "hs-trust-store-v2",
        schemaVersion: 2,
        createdAt: store.createdAt || new Date().toISOString(),
        migratedFrom: "hs-trust-store-v1",
        keys: store.keys.map(key => ({
          ...key,
          rotationCount: 0,
          lastRotated: null
        })),
        policy: {
          requireSignedImports: false,
          allowTOFU: true
        }
      };
      
      return migrated;
    }
  },
  
  "hs-quarantine-v1": {
    toV2: (q) => {
      if (q.format !== "hs-quarantine-v1") {
        throw new ValidationError("Not a quarantine v1");
      }
      
      return {
        format: "hs-quarantine-v2",
        schemaVersion: 2,
        createdAt: q.createdAt || new Date().toISOString(),
        migratedFrom: "hs-quarantine-v1",
        entries: q.entries.map(entry => ({
          ...entry,
          severity: entry.severity || "medium",
          resolved: false
        }))
      };
    }
  }
};

export function migratePack(pack, options = {}) {
  const { targetVersion, dryRun = false } = options;
  
  if (!pack.format && !pack.schema) {
    throw new ValidationError("Pack has no format or schema field");
  }
  
  const format = pack.format || pack.schema;
  
  if (format === "tear-v1") {
    const migrated = Migrations["tear-v1"].toTearV2(pack);
    if (!dryRun) {
      validateSchema(migrated);
    }
    return migrated;
  }
  
  if (format === "hs-trust-store-v1") {
    const migrated = Migrations["hs-trust-store-v1"].toV2(pack);
    if (!dryRun) {
      validateSchema(migrated);
    }
    return migrated;
  }
  
  if (format === "hs-quarantine-v1") {
    const migrated = Migrations["hs-quarantine-v1"].toV2(pack);
    if (!dryRun) {
      validateSchema(migrated);
    }
    return migrated;
  }
  
  if (format === "tear-v2") {
    validateSchema(pack);
    return pack;
  }
  
  throw new ValidationError(`No migration path for format: ${format}`);
}

export function getMigrationPath(pack) {
  const format = pack.format || pack.schema;
  
  const paths = {
    "tear-v1": ["tear-v2"],
    "hs-trust-store-v1": ["hs-trust-store-v2"],
    "hs-quarantine-v1": ["hs-quarantine-v2"],
    "tear-v2": [],
    "hs-trust-store-v2": [],
    "hs-quarantine-v2": []
  };
  
  return paths[format] || null;
}

export function canMigrate(pack) {
  const path = getMigrationPath(pack);
  return path !== null && path.length > 0;
}

export function getLatestVersion(format) {
  const latest = {
    "tear": "tear-v2",
    "hs-trust-store": "hs-trust-store-v2",
    "hs-quarantine": "hs-quarantine-v2"
  };
  
  const base = format.replace(/-v\d+$/, "");
  return latest[base] || format;
}
