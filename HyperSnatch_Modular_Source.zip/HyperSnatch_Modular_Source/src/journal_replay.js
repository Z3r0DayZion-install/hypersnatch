export const JournalEntryType = {
  DECODE_START: "decode_start",
  DECODE_COMPLETE: "decode_complete",
  DECODE_FAIL: "decode_fail",
  QUEUE_ADD: "queue_add",
  QUEUE_REMOVE: "queue_remove",
  EXPORT_START: "export_start",
  EXPORT_COMPLETE: "export_complete",
  STATE_SNAPSHOT: "state_snapshot",
  CHECKPOINT: "checkpoint"
};

export class CrashJournal {
  constructor(options = {}) {
    this.storageKey = options.storageKey || "hs-crash-journal";
    this.maxEntries = options.maxEntries || 1000;
    this.entries = [];
    this.sessionId = this.generateSessionId();
  }
  
  generateSessionId() {
    return `session-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  }
  
  async log(type, data = {}, options = {}) {
    const entry = {
      id: this.generateEntryId(),
      sessionId: this.sessionId,
      timestamp: new Date().toISOString(),
      type,
      data,
      persistent: options.persistent || false
    };
    
    this.entries.push(entry);
    
    if (this.entries.length > this.maxEntries) {
      this.entries = this.entries.slice(-this.maxEntries);
    }
    
    await this.persist();
    
    return entry;
  }
  
  generateEntryId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  }
  
  async persist() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.entries.slice(-100)));
    } catch (e) {
      console.warn("Failed to persist journal:", e);
    }
  }
  
  async load() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        this.entries = JSON.parse(stored);
      }
    } catch (e) {
      console.warn("Failed to load journal:", e);
      this.entries = [];
    }
    return this.entries;
  }
  
  getEntries(options = {}) {
    const { type, sessionId, limit = 100, offset = 0 } = options;
    
    let filtered = this.entries;
    
    if (type) {
      filtered = filtered.filter(e => e.type === type);
    }
    
    if (sessionId) {
      filtered = filtered.filter(e => e.sessionId === sessionId);
    }
    
    return filtered.slice(offset, offset + limit);
  }
  
  getLastSession() {
    if (this.entries.length === 0) return null;
    
    const sessions = new Set(this.entries.map(e => e.sessionId));
    const lastSessionId = Array.from(sessions).pop();
    
    return this.getEntries({ sessionId: lastSessionId });
  }
  
  async clear() {
    this.entries = [];
    localStorage.removeItem(this.storageKey);
  }
  
  getStats() {
    const byType = {};
    const sessions = new Set();
    
    for (const entry of this.entries) {
      byType[entry.type] = (byType[entry.type] || 0) + 1;
      sessions.add(entry.sessionId);
    }
    
    return {
      total: this.entries.length,
      byType,
      sessions: sessions.size,
      currentSession: this.sessionId
    };
  }
}

export class ReplayEngine {
  constructor(journal) {
    this.journal = journal;
    this.replayFunctions = new Map();
  }
  
  registerHandler(type, fn) {
    this.replayFunctions.set(type, fn);
    return this;
  }
  
  async replay(sessionId, options = {}) {
    const { dryRun = false, stopOnError = true } = options;
    
    const entries = this.journal.getEntries({ sessionId });
    
    if (entries.length === 0) {
      return { replayed: 0, skipped: 0, errors: [] };
    }
    
    const results = {
      replayed: 0,
      skipped: 0,
      errors: []
    };
    
    for (const entry of entries) {
      const handler = this.replayFunctions.get(entry.type);
      
      if (!handler) {
        results.skipped++;
        continue;
      }
      
      if (dryRun) {
        results.replayed++;
        continue;
      }
      
      try {
        await handler(entry);
        results.replayed++;
      } catch (e) {
        results.errors.push({
          entryId: entry.id,
          type: entry.type,
          error: e.message
        });
        
        if (stopOnError) {
          break;
        }
      }
    }
    
    return results;
  }
  
  async recover(options = {}) {
    const lastSession = this.journal.getLastSession();
    
    if (!lastSession || lastSession.length === 0) {
      return { recovered: false, reason: "No previous session found" };
    }
    
    const lastEntry = lastSession[lastSession.length - 1];
    
    if (lastEntry.type === JournalEntryType.CHECKPOINT) {
      return {
        recovered: true,
        checkpoint: lastEntry.data,
        sessionId: lastSession[0].sessionId
      };
    }
    
    const incomplete = lastSession.filter(e => 
      e.type === JournalEntryType.DECODE_START && 
      !lastSession.some(le => le.type === JournalEntryType.DECODE_COMPLETE && le.data.id === e.data.id)
    );
    
    return {
      recovered: true,
      incompleteItems: incomplete.map(e => e.data),
      sessionId: lastSession[0].sessionId
    };
  }
}

export class CheckpointManager {
  constructor(options = {}) {
    this.storageKey = options.storageKey || "hs-checkpoints";
    this.maxCheckpoints = options.maxCheckpoints || 10;
    this.checkpoints = [];
  }
  
  async create(name, state) {
    const checkpoint = {
      id: `cp-${Date.now()}`,
      name,
      timestamp: new Date().toISOString(),
      state,
      version: 1
    };
    
    this.checkpoints.push(checkpoint);
    
    if (this.checkpoints.length > this.maxCheckpoints) {
      this.checkpoints = this.checkpoints.slice(-this.maxCheckpoints);
    }
    
    await this.persist();
    
    return checkpoint;
  }
  
  async persist() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.checkpoints));
    } catch (e) {
      console.warn("Failed to persist checkpoints:", e);
    }
  }
  
  async load() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        this.checkpoints = JSON.parse(stored);
      }
    } catch (e) {
      console.warn("Failed to load checkpoints:", e);
    }
    return this.checkpoints;
  }
  
  get(name) {
    return this.checkpoints.find(c => c.name === name);
  }
  
  getLatest() {
    if (this.checkpoints.length === 0) return null;
    return this.checkpoints[this.checkpoints.length - 1];
  }
  
  async restore(name) {
    const checkpoint = this.get(name);
    if (!checkpoint) {
      throw new Error(`Checkpoint not found: ${name}`);
    }
    return checkpoint.state;
  }
  
  async delete(name) {
    this.checkpoints = this.checkpoints.filter(c => c.name !== name);
    await this.persist();
  }
  
  async clear() {
    this.checkpoints = [];
    localStorage.removeItem(this.storageKey);
  }
  
  getAll() {
    return [...this.checkpoints];
  }
}

export function createRecoveryReport(journal, checkpoints) {
  const journalStats = journal.getStats();
  const checkpointList = checkpoints.getAll();
  
  return {
    format: "hs-recovery-report-v1",
    generatedAt: new Date().toISOString(),
    journal: {
      totalEntries: journalStats.total,
      sessions: journalStats.sessions,
      currentSession: journalStats.currentSession,
      byType: journalStats.byType
    },
    checkpoints: checkpointList.map(cp => ({
      id: cp.id,
      name: cp.name,
      timestamp: cp.timestamp
    })),
    latestCheckpoint: checkpointList.length > 0 ? checkpointList[checkpointList.length - 1] : null
  };
}
