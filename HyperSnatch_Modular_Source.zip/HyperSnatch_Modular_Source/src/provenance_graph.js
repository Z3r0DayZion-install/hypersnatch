export function buildProvenanceGraph(decodedItems) {
  const nodes = [];
  const edges = [];
  const strategyNodes = new Map();
  (decodedItems || []).forEach((item, idx) => {
    const decodeNodeId = `decode:${idx}`;
    const strategyId = item?.provenance?.strategyId || "unknown";
    const strategyNodeId = `strategy:${strategyId}`;
    nodes.push({ id: decodeNodeId, type: "decode", url: item.original, out: item.decoded, confidence: item.confidence ?? 0 });
    if (!strategyNodes.has(strategyNodeId)) {
      strategyNodes.set(strategyNodeId, true);
      nodes.push({ id: strategyNodeId, type: "strategy", strategyId });
    }
    edges.push({ from: strategyNodeId, to: decodeNodeId, type: "produced" });
  });
  return { nodes, edges };
}
