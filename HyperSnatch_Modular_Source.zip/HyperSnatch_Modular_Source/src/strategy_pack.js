import { signText, verifyTextSignature } from "./signing.js";

export function createStrategyPack({ packId, version, strategies, createdAt = new Date().toISOString() }) {
  if (!packId || !version) throw new Error("packId and version required");
  if (!Array.isArray(strategies) || !strategies.length) throw new Error("strategies required");
  return {
    format: "hs-strategy-pack-v1",
    packId,
    version,
    createdAt,
    strategies
  };
}

export function validateStrategyPack(pack) {
  if (!pack || typeof pack !== "object") throw new Error("pack must be object");
  if (pack.format !== "hs-strategy-pack-v1") throw new Error("unsupported pack format");
  if (!pack.packId || !pack.version) throw new Error("invalid pack identity");
  if (!Array.isArray(pack.strategies)) throw new Error("invalid strategies");
  for (const s of pack.strategies) {
    if (!s.id || !s.host || typeof s.code !== "string") throw new Error("invalid strategy entry");
  }
  return true;
}

export function canonicalPackText(pack) {
  const strategyLines = [...pack.strategies]
    .sort((a, b) => String(a.id).localeCompare(String(b.id)))
    .map(s => `${s.id}|${s.host}|${s.confidence ?? ""}|${s.code}`);
  return [pack.format, pack.packId, pack.version, pack.createdAt, ...strategyLines].join("\n");
}

export async function signStrategyPack(pack, privateKey, keyId = "strategy-pack-key", cryptoRef = crypto) {
  validateStrategyPack(pack);
  const text = canonicalPackText(pack);
  const sig = await signText(text, privateKey, cryptoRef);
  return {
    ...pack,
    signature: {
      alg: "ECDSA-P256-SHA256",
      keyId,
      sig
    }
  };
}

export async function verifyStrategyPack(pack, publicKey, cryptoRef = crypto) {
  validateStrategyPack(pack);
  if (!pack.signature) return false;
  const text = canonicalPackText(pack);
  return verifyTextSignature(text, pack.signature.sig, publicKey, cryptoRef);
}
