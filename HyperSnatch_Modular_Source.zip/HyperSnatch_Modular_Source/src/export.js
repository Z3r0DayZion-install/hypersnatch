import { normalizePack } from "./schema.js";
import { signText, verifyTextSignature } from "./signing.js";
import { getTrustedKey } from "./truststore.js";

function b64(bytes) {
  let s = "";
  bytes.forEach(b => { s += String.fromCharCode(b); });
  return btoa(s);
}

function fromB64(str) {
  const bin = atob(str);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
  return out;
}

async function deriveAesKey(passphrase, salt, iterations, cryptoRef) {
  const enc = new TextEncoder();
  const keyMaterial = await cryptoRef.subtle.importKey("raw", enc.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
  return cryptoRef.subtle.deriveKey(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function sha256B64(text, cryptoRef) {
  const enc = new TextEncoder();
  const digest = await cryptoRef.subtle.digest("SHA-256", enc.encode(text));
  return b64(new Uint8Array(digest));
}

export function canonicalPackString(pack) {
  return [
    pack.format,
    pack.schemaVersion,
    pack.kind,
    pack.kdf,
    pack.iterations,
    pack.salt,
    pack.iv,
    pack.digest,
    pack.data
  ].join("|");
}

export async function encryptTearPayload(payload, passphrase, cryptoRef = crypto, options = {}) {
  if (!passphrase) throw new Error("Passphrase required");
  if (!cryptoRef?.subtle) throw new Error("WebCrypto unavailable");
  const json = typeof payload === "string" ? payload : JSON.stringify(payload);
  const salt = cryptoRef.getRandomValues(new Uint8Array(16));
  const iv = cryptoRef.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const key = await deriveAesKey(passphrase, salt, 120000, cryptoRef);
  const cipher = await cryptoRef.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(json));
  const digest = await sha256B64(json, cryptoRef);
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "1.3.0",
    kind: options.kind || "tear",
    createdAt: new Date().toISOString(),
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: b64(salt),
    iv: b64(iv),
    digest,
    data: b64(new Uint8Array(cipher))
  };
  if (options.signPrivateKey) {
    const text = canonicalPackString(pack);
    const sig = await signText(text, options.signPrivateKey, cryptoRef);
    pack.signature = {
      alg: "ECDSA-P256-SHA256",
      keyId: options.keyId || "local",
      sig
    };
  }
  return pack;
}

export async function decryptTearPayload(pack, passphrase, cryptoRef = crypto, options = {}) {
  if (!passphrase) throw new Error("Passphrase required");
  const normalized = normalizePack(pack);
  if (normalized.signature && options.verifySignature !== false) {
    let verifyKey = options.verifyPublicKey || null;
    if (!verifyKey && options.trustStore) {
      const trusted = getTrustedKey(options.trustStore, normalized.signature.keyId);
      if (!trusted) throw new Error("Signature key is not trusted");
      verifyKey = await cryptoRef.subtle.importKey(
        "jwk",
        trusted.publicJwk,
        { name: "ECDSA", namedCurve: "P-256" },
        true,
        ["verify"]
      );
    }
    if (!verifyKey && options.allowEmbeddedPublicKey && normalized.signature.publicJwk) {
      verifyKey = await cryptoRef.subtle.importKey(
        "jwk",
        normalized.signature.publicJwk,
        { name: "ECDSA", namedCurve: "P-256" },
        true,
        ["verify"]
      );
    }
    if (!verifyKey) throw new Error("Signature present but no verification key provided");
    const text = canonicalPackString(normalized);
    const ok = await verifyTextSignature(text, normalized.signature.sig, verifyKey, cryptoRef);
    if (!ok) throw new Error("Signature verification failed");
  }
  const salt = fromB64(normalized.salt);
  const iv = fromB64(normalized.iv);
  const data = fromB64(normalized.data);
  const key = await deriveAesKey(passphrase, salt, Number(normalized.iterations || 120000), cryptoRef);
  const plain = await cryptoRef.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
  const text = new TextDecoder().decode(plain);
  const digest = await sha256B64(text, cryptoRef);
  if (normalized.digest && digest !== normalized.digest) throw new Error("Integrity check failed");
  return JSON.parse(text);
}

export async function exportTear(payload, passphrase) {
  const pack = await encryptTearPayload(payload, passphrase);
  const blob = new Blob([JSON.stringify(pack, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "HyperSnatch_export.tear";
  a.click();
}
