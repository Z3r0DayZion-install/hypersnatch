export function compileStrategyCode(code) {
  if (typeof code !== "string" || !code.trim()) throw new Error("strategy code required");
  // Strategy code must return decoded URL string or null.
  const fn = new Function("ctx", `"use strict"; ${code}`);
  return (ctx) => {
    const out = fn(Object.freeze({ ...ctx }));
    if (out === null || out === undefined) return null;
    if (typeof out !== "string") throw new Error("strategy output must be string or null");
    return out;
  };
}

export function buildRuntimeStrategy(entry) {
  if (!entry?.id || !entry?.host) throw new Error("invalid strategy entry");
  const run = compileStrategyCode(entry.code);
  return {
    id: entry.id,
    host: entry.host,
    confidence: Number(entry.confidence ?? 0.6),
    decode(ctx) {
      return run(ctx);
    }
  };
}

export function loadPackStrategies(pack) {
  if (!Array.isArray(pack?.strategies)) throw new Error("invalid pack");
  return pack.strategies.map(buildRuntimeStrategy);
}
