import { signText, verifyTextSignature } from "./signing.js";

function hex(bytes) {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function sha256Hex(text, cryptoRef = crypto) {
  const digest = await cryptoRef.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return hex(new Uint8Array(digest));
}

export async function buildReleaseManifest(artifacts, cryptoRef = crypto) {
  const items = [];
  for (const artifact of artifacts) {
    items.push({
      path: artifact.path,
      bytes: artifact.content.length,
      sha256: await sha256Hex(artifact.content, cryptoRef)
    });
  }
  return {
    format: "hs-release-manifest-v1",
    createdAt: new Date().toISOString(),
    items
  };
}

export function canonicalManifestText(manifest) {
  const rows = [...manifest.items]
    .sort((a, b) => a.path.localeCompare(b.path))
    .map(i => `${i.path}|${i.bytes}|${i.sha256}`);
  return [manifest.format, manifest.createdAt, ...rows].join("\n");
}

export async function signReleaseManifest(manifest, privateKey, keyId = "release-key", cryptoRef = crypto) {
  const text = canonicalManifestText(manifest);
  const sig = await signText(text, privateKey, cryptoRef);
  return {
    ...manifest,
    signature: {
      alg: "ECDSA-P256-SHA256",
      keyId,
      sig
    }
  };
}

export async function verifyReleaseManifest(manifest, publicKey, cryptoRef = crypto) {
  if (!manifest.signature) return false;
  const text = canonicalManifestText(manifest);
  return verifyTextSignature(text, manifest.signature.sig, publicKey, cryptoRef);
}
