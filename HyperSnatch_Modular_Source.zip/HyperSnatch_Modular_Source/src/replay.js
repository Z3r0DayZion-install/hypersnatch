export function createReplayStore(limit = 1000) {
  const events = [];
  return {
    push(event) {
      events.push({ ts: new Date().toISOString(), ...event });
      if (events.length > limit) events.shift();
    },
    all() {
      return [...events];
    },
    filterByType(type) {
      return events.filter(e => e.type === type);
    },
    clear() {
      events.length = 0;
    }
  };
}
