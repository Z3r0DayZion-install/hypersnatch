import { sha256Hex } from "./release.js";

function indexByPath(items) {
  const map = new Map();
  for (const item of items) map.set(item.path, item);
  return map;
}

export async function computeArtifactSnapshot(artifacts, cryptoRef = crypto) {
  const out = [];
  for (const artifact of artifacts) {
    out.push({
      path: artifact.path,
      bytes: artifact.content.length,
      sha256: await sha256Hex(artifact.content, cryptoRef)
    });
  }
  return out;
}

export async function auditReleaseArtifacts(manifest, artifacts, cryptoRef = crypto) {
  const expectedItems = manifest.items || [];
  const actualItems = await computeArtifactSnapshot(artifacts, cryptoRef);
  const expected = indexByPath(expectedItems);
  const actual = indexByPath(actualItems);

  const missing = [];
  const extra = [];
  const mismatched = [];

  for (const [p, exp] of expected.entries()) {
    const act = actual.get(p);
    if (!act) {
      missing.push(p);
      continue;
    }
    if (exp.bytes !== act.bytes || exp.sha256 !== act.sha256) {
      mismatched.push({
        path: p,
        expected: { bytes: exp.bytes, sha256: exp.sha256 },
        actual: { bytes: act.bytes, sha256: act.sha256 }
      });
    }
  }

  for (const [p] of actual.entries()) {
    if (!expected.has(p)) extra.push(p);
  }

  return {
    ok: missing.length === 0 && extra.length === 0 && mismatched.length === 0,
    missing,
    extra,
    mismatched
  };
}
