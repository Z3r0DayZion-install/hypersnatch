import { parseQueueInput } from "./parser.js";
import { decode, decodeWithAdapter } from "./decode.js";
import { RetryMemory } from "./retry.js";
import { createQuarantineStore, shouldQuarantine } from "./quarantine.js";
import { createReplayStore } from "./replay.js";
import { canUseNetwork, createPolicyState, getProfile, meetsConfidence, setProfile, setReleaseChannel } from "./policy.js";
import { runHealthChecks } from "./health.js";
import { createCircuitBreaker } from "./circuit_breaker.js";
import { detectAnomalies } from "./anomaly.js";
import { buildProvenanceGraph } from "./provenance_graph.js";
import { createAuditLedger } from "./ledger.js";
import { detectHost } from "./router.js";

export function createEngine({ tier = "basic" } = {}) {
  const retryMemory = new RetryMemory();
  const quarantine = createQuarantineStore();
  const replay = createReplayStore();
  const policy = createPolicyState();
  const breaker = createCircuitBreaker();
  const ledger = createAuditLedger();
  const state = {
    tier,
    queue: [],
    decoded: [],
    deferred: [],
    quarantine: [],
    replay: [],
    breaker: [],
    anomalies: [],
    provenance: { nodes: [], edges: [] },
    ledger: []
  };

  function syncDeferred(now = Date.now()) {
    state.deferred = retryMemory.pending(now);
  }

  return {
    state,
    policy,
    enqueue(text, source = "manual") {
      const items = parseQueueInput(text, source);
      items.forEach(item => state.queue.push(item.url));
      replay.push({ type: "enqueue", source, count: items.length });
      void ledger.append({ type: "enqueue", source, count: items.length });
      state.replay = replay.all();
      return items.length;
    },
    runQueue(now = Date.now()) {
      let decodedCount = 0;
      let deferredCount = 0;
      while (state.queue.length) {
        const url = state.queue.shift();
        const out = decode(url, state.tier);
        if (out.ok) {
          state.decoded.push({ original: url, decoded: out.decoded, host: out.host, meta: out.meta });
          decodedCount += 1;
        } else {
          retryMemory.defer(url, out.reason, now);
          deferredCount += 1;
        }
      }
      syncDeferred(now);
      state.breaker = breaker.status();
      state.provenance = buildProvenanceGraph(state.decoded);
      state.anomalies = detectAnomalies(replay.all()).findings;
      state.ledger = ledger.all();
      state.replay = replay.all();
      return { decodedCount, deferredCount };
    },
    async runQueueConcurrent(now = Date.now(), options = {}) {
      const profile = getProfile(policy);
      const effectiveConcurrency = options.concurrency || profile.maxConcurrency || policy.maxConcurrency || 3;
      const concurrency = Math.max(1, Math.min(16, effectiveConcurrency));
      let decodedCount = 0;
      let deferredCount = 0;
      while (state.queue.length) {
        const chunk = state.queue.splice(0, concurrency);
        const results = await Promise.all(chunk.map(async (url) => {
          const host = detectHost(url) || "unknown";
          if (breaker.isOpen(host)) return { url, out: { ok: false, reason: "Circuit breaker open" }, host };
          const local = decode(url, state.tier);
          if (local.ok) return { url, out: local, host };
          const adapterEnabled = options.enableOnlineAdapter ?? profile.allowOnlineAdapter;
          if (!adapterEnabled) return { url, out: local, host };
          if (!canUseNetwork(policy)) return { url, out: { ok: false, reason: "Airgapped policy blocks network adapter" }, host };
          const out = await decodeWithAdapter(url, state.tier, options);
          return { url, out, host };
        }));
        for (const rec of results) {
          if (rec.out.ok) {
            if (!meetsConfidence(policy, rec.out.confidence ?? 0.6)) {
              retryMemory.defer(rec.url, "Confidence below policy threshold", now);
              deferredCount += 1;
              replay.push({ type: "deferred", url: rec.url, reason: "confidence-threshold" });
              await ledger.append({ type: "deferred", url: rec.url, reason: "confidence-threshold" });
              breaker.recordFailure(rec.host || "unknown");
              breaker.evaluate(rec.host || "unknown", policy.circuitBreakerThreshold);
              continue;
            }
            state.decoded.push({
              original: rec.url,
              decoded: rec.out.decoded,
              host: rec.out.host,
              meta: rec.out.meta,
              confidence: rec.out.confidence ?? 0.6,
              provenance: rec.out.provenance || { strategyId: "unknown", path: "unknown" }
            });
            decodedCount += 1;
            breaker.recordSuccess(rec.host || "unknown");
            replay.push({ type: "decoded", url: rec.url, strategy: rec.out.provenance?.strategyId || "unknown" });
            await ledger.append({ type: "decoded", url: rec.url, strategy: rec.out.provenance?.strategyId || "unknown" });
          } else {
            const q = shouldQuarantine(rec.url, rec.out.reason);
            if (q.yes) quarantine.add(rec.url, q.reason, q.severity);
            retryMemory.defer(rec.url, rec.out.reason, now);
            deferredCount += 1;
            breaker.recordFailure(rec.host || "unknown");
            breaker.evaluate(rec.host || "unknown", policy.circuitBreakerThreshold);
            replay.push({ type: "deferred", url: rec.url, reason: rec.out.reason });
            await ledger.append({ type: "deferred", url: rec.url, reason: rec.out.reason });
          }
        }
      }
      syncDeferred(now);
      state.quarantine = quarantine.all();
      state.replay = replay.all();
      state.breaker = breaker.status();
      state.provenance = buildProvenanceGraph(state.decoded);
      state.anomalies = detectAnomalies(replay.all()).findings;
      state.ledger = ledger.all();
      return { decodedCount, deferredCount };
    },
    retryReady(now = Date.now()) {
      const ready = retryMemory.ready(now);
      ready.forEach(rec => state.queue.push(rec.url));
      syncDeferred(now);
      replay.push({ type: "retry-ready", moved: ready.length });
      void ledger.append({ type: "retry-ready", moved: ready.length });
      state.replay = replay.all();
      return ready.length;
    },
    setAirgapped(enabled) {
      policy.airgapped = !!enabled;
      replay.push({ type: "policy-airgapped", value: policy.airgapped });
      void ledger.append({ type: "policy-airgapped", value: policy.airgapped });
      state.replay = replay.all();
    },
    setReleaseChannel(channel) {
      setReleaseChannel(policy, channel);
      replay.push({ type: "policy-channel", value: policy.releaseChannel });
      void ledger.append({ type: "policy-channel", value: policy.releaseChannel });
      state.replay = replay.all();
      return policy;
    },
    setProfile(profile) {
      setProfile(policy, profile);
      replay.push({ type: "policy-profile", value: policy.profile });
      void ledger.append({ type: "policy-profile", value: policy.profile });
      state.replay = replay.all();
      return policy;
    },
    health() {
      return runHealthChecks({ state });
    },
    getReplay() {
      return replay.all();
    },
    getQuarantine() {
      return quarantine.all();
    },
    getAnomalies() {
      return detectAnomalies(replay.all());
    },
    getProvenanceGraph() {
      return buildProvenanceGraph(state.decoded);
    },
    getLedger() {
      return ledger.all();
    },
    clear() {
      state.queue = [];
      state.decoded = [];
      state.deferred = [];
      state.tier = "basic";
      quarantine.clear();
      replay.clear();
      state.quarantine = [];
      state.replay = [];
      state.breaker = [];
      state.anomalies = [];
      state.provenance = { nodes: [], edges: [] };
      state.ledger = [];
      breaker.reset();
      return true;
    }
  };
}
