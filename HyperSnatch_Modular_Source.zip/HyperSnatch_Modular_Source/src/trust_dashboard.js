export const TrustDashboard = {
  container: null,
  trustStore: null,
  quarantine: null,
  onUpdate: null,
  
  init(containerId, trustStore, quarantine, onUpdate) {
    this.container = document.getElementById(containerId);
    this.trustStore = trustStore;
    this.quarantine = quarantine;
    this.onUpdate = onUpdate;
    
    if (this.container) {
      this.render();
    }
  },
  
  render() {
    if (!this.container) return;
    
    const stats = this.calculateStats();
    
    this.container.innerHTML = `
      <div class="trust-dashboard">
        <div class="dashboard-header">
          <h2>🛡️ Trust Dashboard</h2>
          <div class="header-actions">
            <button class="btn-refresh" data-action="refresh">↻ Refresh</button>
          </div>
        </div>
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon">🔑</div>
            <div class="stat-content">
              <span class="stat-value">${stats.activeKeys}</span>
              <span class="stat-label">Active Keys</span>
            </div>
          </div>
          
          <div class="stat-card warning">
            <div class="stat-icon">🚫</div>
            <div class="stat-content">
              <span class="stat-value">${stats.revokedKeys}</span>
              <span class="stat-label">Revoked Keys</span>
            </div>
          </div>
          
          <div class="stat-card info">
            <div class="stat-icon">📦</div>
            <div class="stat-content">
              <span class="stat-value">${stats.quarantinePending}</span>
              <span class="stat-label">Quarantine Pending</span>
            </div>
          </div>
          
          <div class="stat-card success">
            <div class="stat-icon">✓</div>
            <div class="stat-content">
              <span class="stat-value">${stats.quarantineResolved}</span>
              <span class="stat-label">Quarantine Resolved</span>
            </div>
          </div>
        </div>
        
        <div class="dashboard-sections">
          <div class="section">
            <h3>Recent Activity</h3>
            <div class="activity-list">
              ${this.renderActivityList(stats.recentActivity)}
            </div>
          </div>
          
          <div class="section">
            <h3>Trust Health</h3>
            <div class="health-indicators">
              ${this.renderHealthIndicators(stats)}
            </div>
          </div>
          
          <div class="section">
            <h3>Quick Actions</h3>
            <div class="quick-actions">
              <button class="action-btn" data-action="export-trust">↑ Export Trust Store</button>
              <button class="action-btn" data-action="import-trust">↓ Import Trust Store</button>
              <button class="action-btn" data-action="clear-quarantine">Clear Quarantine</button>
              <button class="action-btn" data-action="run-diagnostics">🩺 Run Diagnostics</button>
            </div>
          </div>
          
          <div class="section">
            <h3>Trust Policy</h3>
            <div class="policy-settings">
              <label class="toggle-setting">
                <input type="checkbox" id="policy-require-signed" 
                  ${this.trustStore?.policy?.requireSignedImports ? "checked" : ""}>
                <span>Require Signed Imports</span>
              </label>
              <label class="toggle-setting">
                <input type="checkbox" id="policy-tofu" 
                  ${this.trustStore?.policy?.allowTOFU !== false ? "checked" : ""}>
                <span>Allow TOFU (Trust On First Use)</span>
              </label>
              <label class="toggle-setting">
                <input type="checkbox" id="policy-strict" 
                  ${this.trustStore?.policy?.strictMode ? "checked" : ""}>
                <span>Strict Mode</span>
              </label>
            </div>
          </div>
        </div>
        
        ${this.renderKeyTimeline(stats)}
      </div>
    `;
    
    this.attachEvents();
  },
  
  calculateStats() {
    const keys = this.trustStore?.keys || [];
    const entries = this.quarantine?.entries || [];
    
    const activeKeys = keys.filter(k => !k.revoked).length;
    const revokedKeys = keys.filter(k => k.revoked).length;
    const quarantinePending = entries.filter(e => !e.resolved).length;
    const quarantineResolved = entries.filter(e => e.resolved).length;
    
    const recentActivity = [
      ...keys.map(k => ({
        type: "key",
        action: k.revoked ? "revoked" : (k.addedAt > k.lastRotated ? "added" : "rotated"),
        id: k.id,
        timestamp: k.revokedAt || k.lastRotated || k.addedAt
      })),
      ...entries.map(e => ({
        type: "quarantine",
        action: e.resolved ? "resolved" : "added",
        id: e.id,
        timestamp: e.resolvedAt || e.timestamp
      }))
    ].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 10);
    
    return {
      activeKeys,
      revokedKeys,
      quarantinePending,
      quarantineResolved,
      totalKeys: keys.length,
      totalQuarantine: entries.length,
      recentActivity
    };
  },
  
  renderActivityList(activities) {
    if (activities.length === 0) {
      return '<div class="empty-state">No recent activity</div>';
    }
    
    return activities.map(a => `
      <div class="activity-item">
        <span class="activity-icon">
          ${a.type === "key" ? "🔑" : "📦"}
        </span>
        <span class="activity-text">
          ${a.action} ${a.type} ${a.id.slice(0, 8)}...
        </span>
        <span class="activity-time">${this.formatTime(a.timestamp)}</span>
      </div>
    `).join("");
  },
  
  renderHealthIndicators(stats) {
    const indicators = [
      {
        name: "Key Coverage",
        status: stats.activeKeys > 0 ? "good" : "warning",
        message: stats.activeKeys > 0 ? `${stats.activeKeys} active key(s)` : "No active keys"
      },
      {
        name: "Quarantine Queue",
        status: stats.quarantinePending === 0 ? "good" : (stats.quarantinePending < 3 ? "warning" : "critical"),
        message: stats.quarantinePending === 0 ? "Queue empty" : `${stats.quarantinePending} pending`
      },
      {
        name: "Revocation Rate",
        status: stats.revokedKeys === 0 ? "good" : (stats.revokedKeys < stats.totalKeys * 0.5 ? "warning" : "critical"),
        message: stats.revokedKeys === 0 ? "No revocations" : `${stats.revokedKeys}/${stats.totalKeys} revoked`
      }
    ];
    
    return indicators.map(ind => `
      <div class="health-indicator ${ind.status}">
        <span class="indicator-status ${ind.status}"></span>
        <div class="indicator-content">
          <span class="indicator-name">${ind.name}</span>
          <span class="indicator-message">${ind.message}</span>
        </div>
      </div>
    `).join("");
  },
  
  renderKeyTimeline(stats) {
    const keys = this.trustStore?.keys || [];
    
    if (keys.length === 0) return "";
    
    const sortedKeys = [...keys].sort((a, b) => 
      new Date(b.addedAt) - new Date(a.addedAt)
    ).slice(0, 5);
    
    return `
      <div class="section timeline-section">
        <h3>Key Timeline</h3>
        <div class="timeline">
          ${sortedKeys.map((k, i) => `
            <div class="timeline-item ${k.revoked ? "revoked" : "active"}">
              <div class="timeline-marker"></div>
              <div class="timeline-content">
                <span class="timeline-label">${this.escapeHtml(k.label)}</span>
                <span class="timeline-meta">
                  ${k.revoked ? "Revoked" : "Active"} • 
                  Added ${this.formatTime(k.addedAt)}
                  ${k.rotationCount ? ` • Rotated ${k.rotationCount}x` : ""}
                </span>
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  },
  
  attachEvents() {
    const dashboard = this.container;
    
    dashboard.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        this.handleAction(e.target.dataset.action);
      });
    });
    
    dashboard.querySelectorAll(".toggle-setting input").forEach(input => {
      input.addEventListener("change", (e) => {
        this.updatePolicy(e.target.id, e.target.checked);
      });
    });
  },
  
  handleAction(action) {
    switch (action) {
      case "refresh":
        this.render();
        break;
      case "export-trust":
        this.exportTrustStore();
        break;
      case "import-trust":
        this.importTrustStore();
        break;
      case "clear-quarantine":
        this.clearQuarantine();
        break;
      case "run-diagnostics":
        this.runDiagnostics();
        break;
    }
  },
  
  updatePolicy(policyId, value) {
    if (!this.trustStore) {
      this.trustStore = {
        format: "hs-trust-store-v1",
        schemaVersion: 1,
        keys: [],
        policy: {}
      };
    }
    
    if (!this.trustStore.policy) {
      this.trustStore.policy = {};
    }
    
    switch (policyId) {
      case "policy-require-signed":
        this.trustStore.policy.requireSignedImports = value;
        break;
      case "policy-tofu":
        this.trustStore.policy.allowTOFU = value;
        break;
      case "policy-strict":
        this.trustStore.policy.strictMode = value;
        break;
    }
    
    localStorage.setItem("hs-trust-store", JSON.stringify(this.trustStore));
    
    if (this.onUpdate) this.onUpdate(this.trustStore);
  },
  
  exportTrustStore() {
    const exportData = {
      format: this.trustStore?.format || "hs-trust-store-v1",
      schemaVersion: this.trustStore?.schemaVersion || 1,
      exportedAt: new Date().toISOString(),
      keys: (this.trustStore?.keys || []).map(k => ({
        id: k.id,
        label: k.label,
        publicJwk: k.publicJwk,
        revoked: k.revoked,
        addedAt: k.addedAt,
        rotationCount: k.rotationCount
      })),
      policy: this.trustStore?.policy
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hyperSnatch-trust-store-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  },
  
  importTrustStore() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      try {
        const text = await file.text();
        const imported = JSON.parse(text);
        
        if (imported.keys) {
          if (!this.trustStore) {
            this.trustStore = { format: "hs-trust-store-v1", schemaVersion: 1, keys: [] };
          }
          
          imported.keys.forEach(newKey => {
            const exists = this.trustStore.keys.find(k => k.id === newKey.id);
            if (!exists) {
              this.trustStore.keys.push(newKey);
            }
          });
          
          localStorage.setItem("hs-trust-store", JSON.stringify(this.trustStore));
          this.render();
          
          if (this.onUpdate) this.onUpdate(this.trustStore);
          
          alert("Trust store imported successfully");
        }
      } catch (e) {
        alert(`Import failed: ${e.message}`);
      }
    };
    
    input.click();
  },
  
  clearQuarantine() {
    if (!confirm("Clear all quarantine entries?")) return;
    
    if (this.quarantine) {
      this.quarantine.entries = [];
      localStorage.setItem("hs-quarantine", JSON.stringify(this.quarantine));
      this.render();
      
      if (this.onUpdate) this.onUpdate(this.quarantine);
    }
  },
  
  runDiagnostics() {
    if (this.onUpdate) {
      this.onUpdate(null, null, "run-diagnostics");
    }
  },
  
  formatTime(timestamp) {
    if (!timestamp) return "Unknown";
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return "Just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  },
  
  escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
};

export function attachTrustDashboard(containerId, trustStore, quarantine, onUpdate) {
  return TrustDashboard.init(containerId, trustStore, quarantine, onUpdate);
}
