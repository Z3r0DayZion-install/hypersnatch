import { state } from "./state.js";

export function render() {
  const decoded = document.getElementById("decoded");
  const deferred = document.getElementById("deferred");
  const logs = document.getElementById("logs");

  decoded.innerHTML = state.decoded.length
    ? "<table><tr><th>Original</th><th>Decoded</th><th>Host</th><th>Filename</th><th>Size</th><th>Type</th></tr>" +
      state.decoded.map(r => `<tr><td>${esc(r.original)}</td><td>${esc(r.decoded)}</td><td>${esc(r.host)}</td><td>${esc(r.meta?.filename || "")}</td><td>${esc(r.meta?.size || "")}</td><td>${esc(r.meta?.type || "")}</td></tr>`).join("") +
      "</table>"
    : "<p>No decoded items.</p>";

  deferred.innerHTML = state.deferred.length
    ? "<table><tr><th>URL</th><th>Reason</th><th>Attempts</th><th>Next Try</th></tr>" +
      state.deferred.map(r => `<tr><td>${esc(r.url)}</td><td>${esc(r.reason)}</td><td>${esc(r.attempts)}</td><td>${esc(new Date(r.nextTryAt).toISOString())}</td></tr>`).join("") +
      "</table>"
    : "<p>No deferred items.</p>";

  logs.innerHTML = state.logs.map(esc).join("<br>");
}

function esc(v) {
  return String(v).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}
