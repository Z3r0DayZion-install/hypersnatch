function clone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

export function createTrustStore() {
  return {
    schemaVersion: 1,
    activeKeyId: "",
    keys: {}
  };
}

export function addTrustedKey(store, { keyId, publicJwk, createdAt = new Date().toISOString() }) {
  if (!store || typeof store !== "object") throw new Error("Invalid trust store");
  if (!keyId || typeof keyId !== "string") throw new Error("Invalid keyId");
  if (!publicJwk || typeof publicJwk !== "object") throw new Error("Invalid publicJwk");
  if (store.keys[keyId]) throw new Error("Key already exists");
  store.keys[keyId] = {
    keyId,
    status: "active",
    createdAt,
    publicJwk: clone(publicJwk)
  };
  if (!store.activeKeyId) store.activeKeyId = keyId;
  return store;
}

export function rotateActiveKey(store, nextKeyId) {
  if (!store.keys[nextKeyId]) throw new Error("Rotation target key missing");
  const prev = store.activeKeyId;
  if (prev && store.keys[prev] && store.keys[prev].status === "active") {
    store.keys[prev].status = "rotated";
    store.keys[prev].rotatedAt = new Date().toISOString();
  }
  store.keys[nextKeyId].status = "active";
  delete store.keys[nextKeyId].revokedAt;
  delete store.keys[nextKeyId].revocationReason;
  store.activeKeyId = nextKeyId;
  return store;
}

export function revokeKey(store, keyId, reason = "unspecified") {
  const rec = store.keys[keyId];
  if (!rec) throw new Error("Key not found");
  rec.status = "revoked";
  rec.revokedAt = new Date().toISOString();
  rec.revocationReason = reason;
  if (store.activeKeyId === keyId) store.activeKeyId = "";
  return store;
}

export function getTrustedKey(store, keyId) {
  const rec = store?.keys?.[keyId];
  if (!rec) return null;
  if (rec.status === "revoked") return null;
  return rec;
}

export function exportTrustStore(store) {
  if (!store || typeof store !== "object") throw new Error("Invalid trust store");
  return JSON.stringify(store, null, 2);
}

export function importTrustStore(text) {
  const store = JSON.parse(text);
  if (!store || typeof store !== "object" || store.schemaVersion !== 1 || typeof store.keys !== "object") {
    throw new Error("Invalid trust store payload");
  }
  return store;
}
