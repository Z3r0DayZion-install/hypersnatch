import { sha256Hex, buildReleaseManifest, signReleaseManifest, verifyReleaseManifest } from "./release.js";

export async function buildSignedReleasePack(artifacts, options = {}, cryptoRef = crypto) {
  const {
    privateKey,
    keyId = "release",
    includeManifest = true,
    includeSignature = true
  } = options;
  
  if (!Array.isArray(artifacts) || artifacts.length === 0) {
    throw new Error("Artifacts required");
  }
  
  const contentMap = new Map();
  
  for (const artifact of artifacts) {
    const content = artifact.content || "";
    contentMap.set(artifact.path, content);
  }
  
  const manifestItems = [];
  
  for (const [path, content] of contentMap) {
    const hash = await sha256Hex(content, cryptoRef);
    manifestItems.push({
      path,
      bytes: content.length,
      sha256: hash
    });
  }
  
  const manifest = await buildReleaseManifest(
    manifestItems.map(item => ({ path: item.path, content: contentMap.get(item.path) })),
    cryptoRef
  );
  
  let signedManifest = manifest;
  
  if (includeSignature && privateKey) {
    signedManifest = await signReleaseManifest(manifest, privateKey, keyId, cryptoRef);
  }
  
  const pack = {
    format: "hs-release-pack-v1",
    schemaVersion: 1,
    createdAt: new Date().toISOString(),
    app: options.app || "HyperSnatch",
    appVersion: options.appVersion || "1.4.0",
    manifest: signedManifest,
    artifacts: []
  };
  
  for (const [path, content] of contentMap) {
    pack.artifacts.push({
      path,
      data: btoa(content),
      originalBytes: content.length
    });
  }
  
  return pack;
}

function btoa(str) {
  return Buffer.from(str, "binary").toString("base64");
}

export async function verifyReleasePack(pack, publicKey, options = {}, cryptoRef = crypto) {
  const { verifyArtifacts = true } = options;
  
  if (!pack.format || !pack.format.startsWith("hs-release-pack")) {
    throw new Error("Invalid release pack format");
  }
  
  const errors = [];
  const warnings = [];
  
  if (!pack.manifest) {
    errors.push("Missing manifest");
  } else {
    if (pack.manifest.signature && publicKey) {
      const valid = await verifyReleaseManifest(pack.manifest, publicKey, cryptoRef);
      if (!valid) {
        errors.push("Manifest signature verification failed");
      }
    }
    
    if (verifyArtifacts && pack.artifacts) {
      const manifestPaths = new Set(pack.manifest.items.map(i => i.path));
      
      for (const artifact of pack.artifacts) {
        if (!manifestPaths.has(artifact.path)) {
          warnings.push(`Artifact ${artifact.path} not in manifest`);
        }
      }
    }
  }
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
    manifest: pack.manifest,
    artifactCount: pack.artifacts?.length || 0
  };
}

export async function extractReleasePack(pack) {
  const extracted = new Map();
  
  if (!pack.artifacts) {
    return extracted;
  }
  
  for (const artifact of pack.artifacts) {
    try {
      const content = atob(artifact.data);
      extracted.set(artifact.path, content);
    } catch (e) {
      console.warn(`Failed to extract ${artifact.path}:`, e);
    }
  }
  
  return extracted;
}

export function createReleasePackFromFiles(files, options = {}, cryptoRef = crypto) {
  return buildSignedReleasePack(
    files.map(f => ({ path: f.path, content: f.content })),
    options,
    cryptoRef
  );
}

export async function createIncrementalReleasePack(basePack, newArtifacts, options = {}, cryptoRef = crypto) {
  const baseManifest = basePack.manifest;
  const basePaths = new Set(baseManifest.items.map(i => i.path));
  
  const artifacts = [...basePack.artifacts || []];
  
  for (const newArtifact of newArtifacts) {
    if (!basePaths.has(newArtifact.path)) {
      artifacts.push({
        path: newArtifact.path,
        data: btoa(newArtifact.content),
        originalBytes: newArtifact.content.length
      });
    }
  }
  
  const newManifestItems = [];
  
  for (const artifact of artifacts) {
    const content = atob(artifact.data);
    const hash = await sha256Hex(content, cryptoRef);
    newManifestItems.push({
      path: artifact.path,
      bytes: content.length,
      sha256: hash
    });
  }
  
  const manifest = {
    format: "hs-release-manifest-v1",
    createdAt: new Date().toISOString(),
    items: newManifestItems
  };
  
  const { privateKey, keyId, app, appVersion } = options;
  
  if (privateKey) {
    Object.assign(manifest, await signReleaseManifest(manifest, privateKey, keyId, cryptoRef));
  }
  
  return {
    format: "hs-release-pack-v1",
    schemaVersion: 1,
    createdAt: new Date().toISOString(),
    app: app || "HyperSnatch",
    appVersion: appVersion || "1.4.0",
    manifest,
    artifacts,
    incremental: true,
    baseManifest: baseManifest
  };
}

export function getReleasePackInfo(pack) {
  return {
    format: pack.format,
    version: pack.schemaVersion,
    app: pack.app,
    appVersion: pack.appVersion,
    createdAt: pack.createdAt,
    artifactCount: pack.artifacts?.length || 0,
    manifestItems: pack.manifest?.items?.length || 0,
    hasSignature: !!pack.manifest?.signature,
    incremental: pack.incremental || false
  };
}
