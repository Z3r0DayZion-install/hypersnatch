function fileId(pathname) {
  return (pathname.match(/\/file\/([a-z0-9_-]+)/i) || [,""])[1];
}

function rapidId(pathname) {
  return (pathname.match(/\/file\/([a-f0-9]+)/i) || [,""])[1];
}

function parseHtmlDom(html, host) {
  const results = [];
  
  if (typeof DOMParser === "undefined") {
    return results;
  }
  
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  
  const downloadSelectors = [
    "a[download]",
    "a[class*='download']",
    "a[id*='download']",
    "a[class*='btn']",
    "a[class*='button']",
    "a[href*='download']",
    "a[href*='get']",
    "button[data-url]",
    "button[class*='download']",
    "[data-url]",
    "[data-direct-url]",
    "[data-download-url]"
  ];
  
  for (const selector of downloadSelectors) {
    try {
      const elements = doc.querySelectorAll(selector);
      for (const el of elements) {
        let url = el.href || el.dataset.url || el.dataset.directUrl || el.dataset.downloadUrl;
        
        if (url && url.startsWith("//")) {
          url = "https:" + url;
        }
        
        if (url && /^https?:\/\//i.test(url)) {
          const text = el.textContent?.trim() || "";
          results.push({
            url,
            text: text.slice(0, 100),
            type: "download-link",
            fromSelector: selector
          });
        }
      }
    } catch (e) {}
  }
  
  const scriptPatterns = [
    /["']((https?:\/\/[^"'\s]+\.(?:mp4|zip|rar|pdf|exe|iso|7z|avi|mkv))[ "'])/gi,
    /downloadUrl\s*[=:]\s*["']([^"']+)/gi,
    /fileUrl\s*[=:]\s*["']([^"']+)/gi,
    /downloadLink\s*[=:]\s*["']([^"']+)/gi,
    /href\s*[=:]\s*["']([^"']+["'][^"']*download)/gi,
    /window\.location\s*=\s*["']([^"']+)/gi
  ];
  
  const scripts = doc.querySelectorAll("script");
  for (const script of scripts) {
    const text = script.textContent || "";
    for (const pattern of scriptPatterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const url = match[1] || match[2];
        if (url && /^https?:\/\//i.test(url)) {
          results.push({
            url: url.replace(/[ "']/g, ""),
            text: "script-detected",
            type: "script-url"
          });
        }
      }
    }
  }
  
  const metaSelectors = [
    'meta[property="og:video"]',
    'meta[property="og:video:url"]',
    'meta[property="og:image"]',
    'link[rel="video_src"]',
    'link[rel="src"]'
  ];
  
  for (const selector of metaSelectors) {
    const meta = doc.querySelector(selector);
    if (meta) {
      const url = meta.content || meta.getAttribute("href");
      if (url && /^https?:\/\//i.test(url)) {
        results.push({
          url,
          text: `meta-${selector}`,
          type: "meta-tag"
        });
      }
    }
  }
  
  return results;
}

function extractFromForm(doc) {
  const results = [];
  
  const forms = doc.querySelectorAll("form");
  for (const form of forms) {
    const action = form.action;
    const method = form.method?.toUpperCase() || "GET";
    
    const hiddenInputs = [];
    const inputData = {};
    
    for (const input of form.querySelectorAll("input")) {
      const name = input.name;
      const value = input.value;
      if (input.type === "hidden" && name) {
        hiddenInputs.push({ name, value });
        inputData[name] = value;
      }
    }
    
    if (action || hiddenInputs.length > 0) {
      results.push({
        type: "form",
        action,
        method,
        inputs: inputData,
        hiddenCount: hiddenInputs.length
      });
    }
  }
  
  return results;
}

function buildEmloadUrl(fileId, filename = "") {
  const extensions = ["mp4", "zip", "rar", "pdf", "exe", "iso", "7z"];
  const ext = extensions.find(e => filename.toLowerCase().endsWith(e)) || "mp4";
  return `https://cdn.emload.com/stream/${fileId}.${ext}`;
}

function buildKsharedUrl(fileId) {
  return `https://dl.kshared.com/content/${fileId}`;
}

function buildRapidgatorUrl(fileId) {
  return `https://rapidgator.net/download/${fileId}`;
}

export function createDefaultStrategies() {
  return [
    {
      id: "query-stream-param",
      host: "*",
      decode({ urlObj }) {
        const raw = urlObj.searchParams.get("stream") || urlObj.searchParams.get("src") || urlObj.searchParams.get("url");
        if (!raw) return null;
        try {
          const d = decodeURIComponent(raw);
          if (/^https?:\/\//i.test(d)) return d;
        } catch {}
        try {
          const b = atob(raw.replace(/-/g, "+").replace(/_/g, "/"));
          if (/^https?:\/\//i.test(b)) return b;
        } catch {}
        return null;
      },
      confidence: 0.95
    },
    {
      id: "emload-file-path",
      host: "emload.com",
      decode({ urlObj }) {
        const id = fileId(urlObj.pathname);
        return id ? buildEmloadUrl(id) : null;
      },
      confidence: 0.87
    },
    {
      id: "kshared-file-path",
      host: "kshared.com",
      decode({ urlObj }) {
        const id = fileId(urlObj.pathname);
        return id ? buildKsharedUrl(id) : null;
      },
      confidence: 0.82
    },
    {
      id: "rapidgator-file-path",
      host: "rapidgator.net",
      decode({ urlObj }) {
        const id = rapidId(urlObj.pathname);
        return id ? buildRapidgatorUrl(id) : null;
      },
      confidence: 0.8
    },
    {
      id: "dom-extract-emload",
      host: "emload.com",
      decodeWithHtml(html) {
        const results = parseHtmlDom(html, "emload.com");
        
        for (const r of results) {
          if (r.url.includes("cdn.emload.com") || r.url.includes("emload.com/download") || r.url.includes("stream")) {
            return { decoded: r.url, confidence: 0.92, method: "dom-extract", details: r };
          }
        }
        
        const fileIdMatch = html.match(/file[_-]?id["']?\s*[:=]\s*["']?([a-z0-9_-]+)/i) ||
                           html.match(/["']([a-f0-9]{20,})["']/);
        if (fileIdMatch) {
          return { decoded: buildEmloadUrl(fileIdMatch[1]), confidence: 0.85, method: "file-id-regex" };
        }
        
        return null;
      }
    },
    {
      id: "dom-extract-kshared",
      host: "kshared.com",
      decodeWithHtml(html) {
        const results = parseHtmlDom(html, "kshared.com");
        
        for (const r of results) {
          if (r.url.includes("dl.kshared.com") || r.url.includes("kshared.com/download") || r.url.includes("content")) {
            return { decoded: r.url, confidence: 0.92, method: "dom-extract", details: r };
          }
        }
        
        const fileIdMatch = html.match(/file[_-]?id["']?\s*[:=]\s*["']?([a-z0-9_-]+)/i);
        if (fileIdMatch) {
          return { decoded: buildKsharedUrl(fileIdMatch[1]), confidence: 0.85, method: "file-id-regex" };
        }
        
        return null;
      }
    },
    {
      id: "dom-extract-rapidgator",
      host: "rapidgator.net",
      decodeWithHtml(html) {
        const results = parseHtmlDom(html, "rapidgator.net");
        
        for (const r of results) {
          if (r.url.includes("rapidgator.net/download") || r.url.includes("rapidgator.net/f")) {
            return { decoded: r.url, confidence: 0.92, method: "dom-extract", details: r };
          }
        }
        
        const fileIdMatch = html.match(/file[_-]?id["']?\s*[:=]\s*["']?([a-f0-9]+)/i);
        if (fileIdMatch) {
          return { decoded: buildRapidgatorUrl(fileIdMatch[1]), confidence: 0.85, method: "file-id-regex" };
        }
        
        return null;
      }
    },
    {
      id: "dom-extract-generic",
      host: "*",
      decodeWithHtml(html) {
        const results = parseHtmlDom(html, "generic");
        
        const directLinks = results.filter(r => 
          r.type === "download-link" || 
          r.url.includes("download") ||
          r.url.match(/\.(mp4|zip|rar|pdf|exe|iso|7z|avi|mkv)/i)
        );
        
        if (directLinks.length > 0) {
          return { 
            decoded: directLinks[0].url, 
            confidence: 0.88, 
            method: "dom-extract",
            allLinks: directLinks.map(r => r.url)
          };
        }
        
        return null;
      }
    },
    {
      id: "form-extract",
      host: "*",
      decodeWithHtml(html) {
        if (typeof DOMParser === "undefined") return null;
        
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        const forms = extractFromForm(doc);
        
        for (const form of forms) {
          if (form.action && form.action.includes("download")) {
            const url = new URL(form.action, "https://example.com");
            for (const [name, value] of Object.entries(form.inputs)) {
              url.searchParams.set(name, value);
            }
            return { decoded: url.toString(), confidence: 0.75, method: "form-extract" };
          }
        }
        
        return null;
      }
    }
  ];
}

export function createStrategyRegistry() {
  const strategies = createDefaultStrategies();
  return {
    list() {
      return [...strategies];
    },
    register(strategy) {
      if (!strategy || typeof strategy.decode !== "function" || !strategy.id) throw new Error("Invalid strategy");
      strategies.push(strategy);
      return strategy.id;
    },
    apply({ host, urlObj, url }) {
      for (const strategy of strategies) {
        if (!strategy.decode) continue;
        if (strategy.host !== "*" && strategy.host !== host) continue;
        const decoded = strategy.decode({ host, urlObj, url });
        if (decoded) {
          return {
            decoded,
            strategyId: strategy.id,
            confidence: Number(strategy.confidence || 0.6)
          };
        }
      }
      return null;
    },
    applyWithHtml({ host, html, url }) {
      for (const strategy of strategies) {
        if (!strategy.decodeWithHtml) continue;
        if (strategy.host !== "*" && strategy.host !== host) continue;
        
        const result = strategy.decodeWithHtml(html, host, url);
        if (result) {
          return {
            decoded: result.decoded,
            strategyId: strategy.id,
            confidence: result.confidence,
            method: result.method,
            details: result.details || result
          };
        }
      }
      return null;
    }
  };
}
