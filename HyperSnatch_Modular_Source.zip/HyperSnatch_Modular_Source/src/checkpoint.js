export function createCheckpointBundle({ policy, trustStore, decoded, deferred, replay, createdAt = new Date().toISOString() }) {
  return {
    format: "hs-checkpoint-v1",
    createdAt,
    policy: policy || {},
    trustStore: trustStore || {},
    decoded: decoded || [],
    deferred: deferred || [],
    replay: replay || []
  };
}

export function restoreCheckpointBundle(bundle) {
  if (bundle?.format !== "hs-checkpoint-v1") throw new Error("invalid checkpoint bundle");
  return {
    policy: bundle.policy || {},
    trustStore: bundle.trustStore || {},
    decoded: bundle.decoded || [],
    deferred: bundle.deferred || [],
    replay: bundle.replay || []
  };
}
