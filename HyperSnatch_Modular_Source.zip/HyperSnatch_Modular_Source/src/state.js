export const state = {
  tier: "basic",
  queue: [],
  decoded: [],
  deferred: [],
  logs: [],
  retryMemory: null
};

export function log(msg) {
  state.logs.push(`[${new Date().toISOString()}] ${msg}`);
  if (state.logs.length > 300) state.logs.shift();
}
