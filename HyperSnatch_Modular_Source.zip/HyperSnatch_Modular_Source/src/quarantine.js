export function createQuarantineStore() {
  const list = [];
  return {
    add(url, reason, severity = "medium") {
      const item = {
        url,
        reason,
        severity,
        quarantinedAt: new Date().toISOString()
      };
      list.push(item);
      return item;
    },
    all() {
      return [...list];
    },
    clear() {
      list.length = 0;
    }
  };
}

export function shouldQuarantine(url, reason) {
  if (/javascript:/i.test(url)) return { yes: true, severity: "high", reason: "JS scheme blocked" };
  if (/data:/i.test(url)) return { yes: true, severity: "high", reason: "Data URL blocked" };
  if (reason === "Malformed URL") return { yes: true, severity: "low", reason };
  if (reason === "Unsupported host") return { yes: true, severity: "low", reason };
  return { yes: false, severity: "none", reason: "" };
}
