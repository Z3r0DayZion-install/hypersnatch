export function createFederatedSnapshot({ orgId, trustStore, createdAt = new Date().toISOString() }) {
  if (!orgId) throw new Error("orgId required");
  if (!trustStore || typeof trustStore !== "object") throw new Error("trustStore required");
  return {
    format: "hs-trust-federation-v1",
    orgId,
    createdAt,
    trustStore
  };
}

export function mergeFederatedSnapshot(localTrustStore, snapshot) {
  if (snapshot?.format !== "hs-trust-federation-v1") throw new Error("invalid snapshot");
  const merged = JSON.parse(JSON.stringify(localTrustStore));
  merged.keys ||= {};
  const incoming = snapshot.trustStore?.keys || {};
  for (const [keyId, rec] of Object.entries(incoming)) {
    const existing = merged.keys[keyId];
    if (!existing) {
      merged.keys[keyId] = rec;
      continue;
    }
    // Revocation wins over other states.
    if (existing.status !== "revoked" && rec.status === "revoked") {
      merged.keys[keyId] = rec;
    }
  }
  return merged;
}
