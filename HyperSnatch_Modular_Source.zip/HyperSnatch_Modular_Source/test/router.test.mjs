import test from "node:test";
import assert from "node:assert/strict";
import { detectHost, gateHost, isSupportedHost } from "../src/router.js";

test("detectHost normalizes www", () => {
  assert.equal(detectHost("https://www.emload.com/file/x"), "emload.com");
});

test("isSupportedHost checks known set", () => {
  assert.equal(isSupportedHost("rapidgator.net"), true);
  assert.equal(isSupportedHost("example.com"), false);
});

test("gateHost enforces tier lock", () => {
  assert.equal(gateHost("kshared.com", "basic").ok, false);
  assert.equal(gateHost("kshared.com", "advanced").ok, true);
});
