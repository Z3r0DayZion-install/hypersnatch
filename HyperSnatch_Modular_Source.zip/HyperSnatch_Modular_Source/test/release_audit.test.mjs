import test from "node:test";
import assert from "node:assert/strict";
import { buildReleaseManifest } from "../src/release.js";
import { auditReleaseArtifacts } from "../src/release_audit.js";

test("audit passes for matching artifact set", async () => {
  const artifacts = [
    { path: "a.txt", content: "alpha" },
    { path: "b.txt", content: "beta" }
  ];
  const manifest = await buildReleaseManifest(artifacts, globalThis.crypto);
  const out = await auditReleaseArtifacts(manifest, artifacts, globalThis.crypto);
  assert.equal(out.ok, true);
});

test("audit catches mismatch and missing files", async () => {
  const base = [
    { path: "a.txt", content: "alpha" },
    { path: "b.txt", content: "beta" }
  ];
  const manifest = await buildReleaseManifest(base, globalThis.crypto);
  const changed = [{ path: "a.txt", content: "alpha-CHANGED" }];
  const out = await auditReleaseArtifacts(manifest, changed, globalThis.crypto);
  assert.equal(out.ok, false);
  assert.equal(out.missing.includes("b.txt"), true);
  assert.equal(out.mismatched.length, 1);
});

test("audit catches extra files", async () => {
  const base = [{ path: "a.txt", content: "alpha" }];
  const manifest = await buildReleaseManifest(base, globalThis.crypto);
  const changed = [
    { path: "a.txt", content: "alpha" },
    { path: "extra.txt", content: "x" }
  ];
  const out = await auditReleaseArtifacts(manifest, changed, globalThis.crypto);
  assert.equal(out.ok, false);
  assert.equal(out.extra.includes("extra.txt"), true);
});
