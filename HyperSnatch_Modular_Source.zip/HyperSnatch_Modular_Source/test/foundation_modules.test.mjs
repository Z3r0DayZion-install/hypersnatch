import test from "node:test";
import assert from "node:assert/strict";
import { createStrategyPack, signStrategyPack, verifyStrategyPack } from "../src/strategy_pack.js";
import { generateSigningKeyPair } from "../src/signing.js";
import { loadPackStrategies } from "../src/plugin_sdk.js";
import { applyPolicyTemplate, POLICY_TEMPLATES } from "../src/policy_templates.js";
import { createFederatedSnapshot, mergeFederatedSnapshot } from "../src/federation.js";
import { detectDecodeDrift } from "../src/drift.js";
import { createCheckpointBundle, restoreCheckpointBundle } from "../src/checkpoint.js";

test("strategy pack sign/verify and plugin load", async () => {
  const pack = createStrategyPack({
    packId: "p1",
    version: "1.0.0",
    strategies: [{ id: "s1", host: "example.com", confidence: 0.8, code: "return 'https://x/y.mp4';" }]
  });
  const keys = await generateSigningKeyPair(globalThis.crypto);
  const signed = await signStrategyPack(pack, keys.privateKey, "k1", globalThis.crypto);
  const ok = await verifyStrategyPack(signed, keys.publicKey, globalThis.crypto);
  assert.equal(ok, true);
  const runtime = loadPackStrategies(signed);
  assert.equal(runtime[0].decode({}), "https://x/y.mp4");
});

test("policy template apply", () => {
  const target = {};
  applyPolicyTemplate(target, "regulated");
  assert.equal(target.profile, POLICY_TEMPLATES.regulated.profile);
});

test("federated snapshot merge respects revocation", () => {
  const local = { keys: { a: { status: "active" } } };
  const snap = createFederatedSnapshot({
    orgId: "o1",
    trustStore: { keys: { a: { status: "revoked" }, b: { status: "active" } } }
  });
  const out = mergeFederatedSnapshot(local, snap);
  assert.equal(out.keys.a.status, "revoked");
  assert.equal(out.keys.b.status, "active");
});

test("drift detector spots changed decode", () => {
  const out = detectDecodeDrift(
    [{ original: "u", decoded: "a" }],
    [{ original: "u", decoded: "b" }]
  );
  assert.equal(out.ok, false);
  assert.equal(out.changed.length, 1);
});

test("checkpoint bundle restore", () => {
  const bundle = createCheckpointBundle({ policy: { x: 1 }, decoded: [{ a: 1 }] });
  const restored = restoreCheckpointBundle(bundle);
  assert.equal(restored.policy.x, 1);
  assert.equal(restored.decoded.length, 1);
});
