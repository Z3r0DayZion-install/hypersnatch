import test from "node:test";
import assert from "node:assert/strict";
import { decodeWithAdapter } from "../src/decode.js";
import { extractStreamCandidates } from "../src/online_adapter.js";

test("extractStreamCandidates finds absolute and relative links", () => {
  const html = `
    <video src="https://cdn.example.com/video.mp4"></video>
    <script>const x='/hls/main.m3u8';</script>
  `;
  const out = extractStreamCandidates(html, "https://emload.com/file/abc");
  assert.equal(out.some(v => v.includes("video.mp4")), true);
  assert.equal(out.some(v => v.includes("/hls/main.m3u8")), true);
});

test("decodeWithAdapter falls back to adapter when local path missing", async () => {
  const fakeFetch = async () => ({
    ok: true,
    text: async () => '<source src="https://cdn.example.com/fallback.mp4">'
  });
  const out = await decodeWithAdapter("https://emload.com/file/", "basic", {
    enableOnlineAdapter: true,
    fetchImpl: fakeFetch
  });
  assert.equal(out.ok, true);
  assert.equal(out.decoded, "https://cdn.example.com/fallback.mp4");
});
