import test from "node:test";
import assert from "node:assert/strict";
import { extractFolderId, extractUrls, parseQueueInput } from "../src/parser.js";

test("extractUrls finds multiple links and strips trailing punctuation", () => {
  const text = "x https://emload.com/file/abc, y https://kshared.com/file/def.";
  const urls = extractUrls(text);
  assert.deepEqual(urls, ["https://emload.com/file/abc", "https://kshared.com/file/def"]);
});

test("parseQueueInput deduplicates", () => {
  const text = "https://emload.com/file/a https://emload.com/file/a";
  const out = parseQueueInput(text);
  assert.equal(out.length, 1);
  assert.equal(out[0].source, "manual");
});

test("extractFolderId returns id when present", () => {
  assert.equal(extractFolderId("https://emload.com/folder/abc_123"), "abc_123");
});

test("parseQueueInput preserves source label", () => {
  const out = parseQueueInput("https://emload.com/file/a", "clipboard");
  assert.equal(out[0].source, "clipboard");
});
