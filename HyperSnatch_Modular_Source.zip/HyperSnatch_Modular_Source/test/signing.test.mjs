import test from "node:test";
import assert from "node:assert/strict";
import {
  exportPrivateJwk,
  exportPublicJwk,
  generateSigningKeyPair,
  importPrivateJwk,
  importPublicJwk,
  signText,
  verifyTextSignature
} from "../src/signing.js";

test("signing roundtrip verify true", async () => {
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const sig = await signText("hello", pair.privateKey, globalThis.crypto);
  const ok = await verifyTextSignature("hello", sig, pair.publicKey, globalThis.crypto);
  assert.equal(ok, true);
});

test("jwk export/import roundtrip works", async () => {
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const pubJwk = await exportPublicJwk(pair.publicKey, globalThis.crypto);
  const prvJwk = await exportPrivateJwk(pair.privateKey, globalThis.crypto);
  const pub = await importPublicJwk(pubJwk, globalThis.crypto);
  const prv = await importPrivateJwk(prvJwk, globalThis.crypto);
  const sig = await signText("m", prv, globalThis.crypto);
  const ok = await verifyTextSignature("m", sig, pub, globalThis.crypto);
  assert.equal(ok, true);
});
