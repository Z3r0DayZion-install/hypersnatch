import test from "node:test";
import assert from "node:assert/strict";
import {
  addTrustedKey,
  createTrustStore,
  exportTrustStore,
  getTrustedKey,
  importTrustStore,
  revokeKey,
  rotateActiveKey
} from "../src/truststore.js";
import { generateSigningKeyPair, exportPublicJwk } from "../src/signing.js";

test("trust store add/get works", async () => {
  const store = createTrustStore();
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const jwk = await exportPublicJwk(pair.publicKey, globalThis.crypto);
  addTrustedKey(store, { keyId: "k1", publicJwk: jwk });
  const key = getTrustedKey(store, "k1");
  assert.ok(key);
  assert.equal(store.activeKeyId, "k1");
});

test("trust store rotate and revoke", async () => {
  const store = createTrustStore();
  const p1 = await generateSigningKeyPair(globalThis.crypto);
  const p2 = await generateSigningKeyPair(globalThis.crypto);
  addTrustedKey(store, { keyId: "k1", publicJwk: await exportPublicJwk(p1.publicKey, globalThis.crypto) });
  addTrustedKey(store, { keyId: "k2", publicJwk: await exportPublicJwk(p2.publicKey, globalThis.crypto) });
  rotateActiveKey(store, "k2");
  assert.equal(store.activeKeyId, "k2");
  assert.equal(store.keys.k1.status, "rotated");
  revokeKey(store, "k2", "compromised");
  assert.equal(getTrustedKey(store, "k2"), null);
});

test("trust store export/import roundtrip", async () => {
  const store = createTrustStore();
  const pair = await generateSigningKeyPair(globalThis.crypto);
  addTrustedKey(store, { keyId: "k1", publicJwk: await exportPublicJwk(pair.publicKey, globalThis.crypto) });
  const json = exportTrustStore(store);
  const imported = importTrustStore(json);
  assert.equal(imported.schemaVersion, 1);
  assert.ok(imported.keys.k1);
});
