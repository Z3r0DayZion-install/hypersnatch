import test from "node:test";
import assert from "node:assert/strict";
import { migratePack, getMigrationPath, canMigrate, getLatestVersion } from "../src/migrations.js";

test("migratePack tear-v1 to tear-v2", () => {
  const old = {
    format: "tear-v1",
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA=="
  };
  
  const migrated = migratePack(old);
  
  assert.equal(migrated.format, "tear-v2");
  assert.equal(migrated.schemaVersion, 2);
  assert.equal(migrated.migratedFrom, "tear-v1");
});

test("migratePack tear-v2 passes through", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "1.4.0",
    kind: "tear",
    createdAt: "2026-02-18T00:00:00.000Z",
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA=="
  };
  
  const result = migratePack(pack);
  assert.equal(result.format, "tear-v2");
});

test("migratePack trust-store-v1 to v2", () => {
  const old = {
    format: "hs-trust-store-v1",
    schemaVersion: 1,
    keys: [
      { id: "k1", label: "Test", publicJwk: {}, revoked: false }
    ]
  };
  
  const migrated = migratePack(old);
  
  assert.equal(migrated.format, "hs-trust-store-v2");
  assert.equal(migrated.schemaVersion, 2);
  assert.equal(migrated.keys[0].rotationCount, 0);
  assert.ok(migrated.policy);
});

test("getMigrationPath tear-v1", () => {
  const path = getMigrationPath({ format: "tear-v1" });
  assert.deepEqual(path, ["tear-v2"]);
});

test("getMigrationPath tear-v2", () => {
  const path = getMigrationPath({ format: "tear-v2" });
  assert.deepEqual(path, []);
});

test("getMigrationPath unknown", () => {
  const path = getMigrationPath({ format: "unknown" });
  assert.equal(path, null);
});

test("canMigrate returns true for migratable", () => {
  assert.equal(canMigrate({ format: "tear-v1" }), true);
  assert.equal(canMigrate({ format: "hs-trust-store-v1" }), true);
});

test("canMigrate returns false for latest", () => {
  assert.equal(canMigrate({ format: "tear-v2" }), false);
});

test("getLatestVersion returns correct version", () => {
  assert.equal(getLatestVersion("tear-v1"), "tear-v2");
  assert.equal(getLatestVersion("tear-v2"), "tear-v2");
  assert.equal(getLatestVersion("hs-trust-store-v1"), "hs-trust-store-v2");
  assert.equal(getLatestVersion("unknown"), "unknown");
});
