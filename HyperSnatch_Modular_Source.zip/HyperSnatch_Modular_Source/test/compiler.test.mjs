import test from "node:test";
import assert from "node:assert/strict";
import { compileTearDataPack, compileTearBundle, compileSignedDoctorReport } from "../src/compiler.js";

test("compileTearDataPack creates valid tear-v2 pack", async () => {
  const payload = { test: "data", items: [1, 2, 3] };
  const pack = await compileTearDataPack(payload, { passphrase: "test123" });
  
  assert.equal(pack.format, "tear-v2");
  assert.equal(pack.schemaVersion, 2);
  assert.equal(pack.kind, "tear");
  assert.ok(pack.salt);
  assert.ok(pack.iv);
  assert.ok(pack.digest);
  assert.ok(pack.data);
});

test("compileTearDataPack with deterministic mode", async () => {
  const payload = { test: "data" };
  const pack1 = await compileTearDataPack(payload, { passphrase: "test123", deterministic: true });
  const pack2 = await compileTearDataPack(payload, { passphrase: "test123", deterministic: true });
  
  assert.equal(pack1.createdAt, "2026-02-18T00:00:00.000Z");
  assert.equal(pack2.createdAt, "2026-02-18T00:00:00.000Z");
});

test("compileTearBundle creates valid bundle", async () => {
  const entries = [
    { path: "a.txt", content: "hello", type: "text" },
    { path: "b.txt", content: "world", type: "text" }
  ];
  
  const bundle = await compileTearBundle(entries, { deterministic: true });
  
  assert.equal(bundle.schema, "hs-tear-bundle-1");
  assert.equal(bundle.schemaVersion, 1);
  assert.ok(bundle.manifest);
  assert.equal(bundle.manifest.entries.length, 2);
});

test("compileTearBundle sorts entries by path", async () => {
  const entries = [
    { path: "z.txt", content: "z", type: "text" },
    { path: "a.txt", content: "a", type: "text" },
    { path: "m.txt", content: "m", type: "text" }
  ];
  
  const bundle = await compileTearBundle(entries);
  
  assert.equal(bundle.manifest.entries[0].path, "a.txt");
  assert.equal(bundle.manifest.entries[1].path, "m.txt");
  assert.equal(bundle.manifest.entries[2].path, "z.txt");
});

test("compileSignedDoctorReport creates valid report", async () => {
  const checks = [
    { name: "crypto", status: "pass", details: "OK" },
    { name: "storage", status: "pass", details: "OK" }
  ];
  
  const report = await compileSignedDoctorReport(checks, { deterministic: true });
  
  assert.equal(report.format, "hs-doctor-report-v1");
  assert.equal(report.schemaVersion, 1);
  assert.equal(report.createdAt, "2026-02-18T00:00:00.000Z");
  assert.equal(report.checks.length, 2);
});

test("compileTearDataPack requires passphrase", async () => {
  await assert.rejects(
    () => compileTearDataPack({ test: "data" }, {}),
    /Passphrase required/
  );
});
