import test from "node:test";
import assert from "node:assert/strict";
import { RetryMemory, nextDelayMs } from "../src/retry.js";

test("nextDelayMs increases with attempts and caps", () => {
  assert.equal(nextDelayMs(1), 5000);
  assert.equal(nextDelayMs(3), 15000);
  assert.equal(nextDelayMs(99), 120000);
});

test("RetryMemory tracks attempts and readiness", () => {
  const rm = new RetryMemory();
  const now = 1000;
  const rec = rm.defer("https://emload.com/file/a", "fail", now);
  assert.equal(rec.attempts, 1);
  assert.equal(rm.ready(now).length, 0);
  assert.equal(rm.ready(now + 6000).length, 1);
});
