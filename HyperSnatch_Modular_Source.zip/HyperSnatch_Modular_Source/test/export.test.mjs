import test from "node:test";
import assert from "node:assert/strict";
import { canonicalPackString, decryptTearPayload, encryptTearPayload } from "../src/export.js";
import { exportPublicJwk, generateSigningKeyPair } from "../src/signing.js";
import { addTrustedKey, createTrustStore, revokeKey } from "../src/truststore.js";

test("encryptTearPayload returns tear-v2 structure", async () => {
  const payload = { decoded: [{ a: 1 }], deferred: [] };
  const out = await encryptTearPayload(payload, "secret-pass", globalThis.crypto);
  assert.equal(out.format, "tear-v2");
  assert.equal(out.schemaVersion, 2);
  assert.equal(typeof out.digest, "string");
  assert.equal(typeof out.data, "string");
  assert.ok(out.data.length > 10);
});

test("encrypt/decrypt roundtrip returns original payload", async () => {
  const payload = { decoded: [{ id: "x" }], deferred: [{ id: "y" }] };
  const pack = await encryptTearPayload(payload, "roundtrip", globalThis.crypto);
  const decoded = await decryptTearPayload(pack, "roundtrip", globalThis.crypto);
  assert.deepEqual(decoded, payload);
});

test("decrypt with wrong passphrase fails", async () => {
  const payload = { ok: true };
  const pack = await encryptTearPayload(payload, "correct", globalThis.crypto);
  await assert.rejects(() => decryptTearPayload(pack, "wrong", globalThis.crypto));
});

test("digest mismatch fails integrity check", async () => {
  const payload = { ok: true };
  const pack = await encryptTearPayload(payload, "correct", globalThis.crypto);
  pack.digest = "tampered";
  await assert.rejects(() => decryptTearPayload(pack, "correct", globalThis.crypto));
});

test("legacy tear-v1 pack decrypts via migration path", async () => {
  const payload = { old: true };
  const pack = await encryptTearPayload(payload, "legacy-pass", globalThis.crypto);
  const legacy = {
    format: "tear-v1",
    kdf: pack.kdf,
    iterations: pack.iterations,
    salt: pack.salt,
    iv: pack.iv,
    digest: pack.digest,
    data: pack.data
  };
  const out = await decryptTearPayload(legacy, "legacy-pass", globalThis.crypto);
  assert.deepEqual(out, payload);
});

test("signed pack verifies and decrypts", async () => {
  const payload = { secure: true };
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const pack = await encryptTearPayload(payload, "sig-pass", globalThis.crypto, {
    signPrivateKey: pair.privateKey,
    keyId: "test-key"
  });
  assert.ok(pack.signature);
  assert.equal(pack.signature.keyId, "test-key");
  const out = await decryptTearPayload(pack, "sig-pass", globalThis.crypto, {
    verifyPublicKey: pair.publicKey
  });
  assert.deepEqual(out, payload);
});

test("signed pack without verification key is rejected", async () => {
  const payload = { secure: true };
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const pack = await encryptTearPayload(payload, "sig-pass", globalThis.crypto, {
    signPrivateKey: pair.privateKey
  });
  await assert.rejects(() => decryptTearPayload(pack, "sig-pass", globalThis.crypto));
});

test("signed pack fails if canonical data tampered", async () => {
  const payload = { secure: true };
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const pack = await encryptTearPayload(payload, "sig-pass", globalThis.crypto, {
    signPrivateKey: pair.privateKey
  });
  const original = canonicalPackString(pack);
  pack.kind = "vault";
  const changed = canonicalPackString(pack);
  assert.notEqual(changed, original);
  await assert.rejects(() => decryptTearPayload(pack, "sig-pass", globalThis.crypto, {
    verifyPublicKey: pair.publicKey
  }));
});

test("signed pack verifies via trust store", async () => {
  const payload = { secure: "trust-store" };
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const pack = await encryptTearPayload(payload, "store-pass", globalThis.crypto, {
    signPrivateKey: pair.privateKey,
    keyId: "k-trusted"
  });
  const store = createTrustStore();
  addTrustedKey(store, {
    keyId: "k-trusted",
    publicJwk: await exportPublicJwk(pair.publicKey, globalThis.crypto)
  });
  const out = await decryptTearPayload(pack, "store-pass", globalThis.crypto, { trustStore: store });
  assert.deepEqual(out, payload);
});

test("signed pack fails when key revoked in trust store", async () => {
  const payload = { secure: "revoked" };
  const pair = await generateSigningKeyPair(globalThis.crypto);
  const pack = await encryptTearPayload(payload, "store-pass", globalThis.crypto, {
    signPrivateKey: pair.privateKey,
    keyId: "k-revoked"
  });
  const store = createTrustStore();
  addTrustedKey(store, {
    keyId: "k-revoked",
    publicJwk: await exportPublicJwk(pair.publicKey, globalThis.crypto)
  });
  revokeKey(store, "k-revoked", "compromised");
  await assert.rejects(() => decryptTearPayload(pack, "store-pass", globalThis.crypto, { trustStore: store }));
});
