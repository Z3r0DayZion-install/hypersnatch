import test from "node:test";
import assert from "node:assert/strict";
import { normalizePack, validatePack } from "../src/schema.js";

test("validatePack accepts minimal valid tear-v2 pack", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "x",
    kind: "tear",
    createdAt: new Date().toISOString(),
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA=="
  };
  assert.equal(validatePack(pack), true);
});

test("normalizePack migrates tear-v1 to tear-v2", () => {
  const old = {
    format: "tear-v1",
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA=="
  };
  const migrated = normalizePack(old);
  assert.equal(migrated.format, "tear-v2");
  assert.equal(migrated.schemaVersion, 2);
});

test("validatePack accepts signed envelope", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "x",
    kind: "tear",
    createdAt: new Date().toISOString(),
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA==",
    signature: {
      alg: "ECDSA-P256-SHA256",
      keyId: "k1",
      sig: "QUJDRA=="
    }
  };
  assert.equal(validatePack(pack), true);
});
