import test from "node:test";
import assert from "node:assert/strict";
import { decode } from "../src/decode.js";

test("decode emload file id", () => {
  const out = decode("https://emload.com/file/abc123", "basic");
  assert.equal(out.ok, true);
  assert.equal(out.decoded, "https://cdn.emload.com/stream/abc123.mp4");
});

test("decode from stream query has priority", () => {
  const out = decode("https://emload.com/file/abc?stream=https%3A%2F%2Fcdn.x%2Fy.mp4", "basic");
  assert.equal(out.ok, true);
  assert.equal(out.decoded, "https://cdn.x/y.mp4");
});

test("kshared is tier-gated in basic", () => {
  const out = decode("https://kshared.com/file/zzz", "basic");
  assert.equal(out.ok, false);
  assert.equal(out.reason, "Tier gate");
});

test("malformed url fails", () => {
  const out = decode("not-a-url", "basic");
  assert.equal(out.ok, false);
  assert.equal(out.reason, "Malformed URL");
});

test("rapidgator path decodes for advanced tier", () => {
  const out = decode("https://rapidgator.net/file/abc123ef", "advanced");
  assert.equal(out.ok, true);
  assert.equal(out.decoded, "https://rapidgator.net/download/abc123ef");
});
