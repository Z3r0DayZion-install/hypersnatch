import test from "node:test";
import assert from "node:assert/strict";
import { createStrategyRegistry } from "../src/strategies.js";
import { detectAnomalies } from "../src/anomaly.js";
import { buildProvenanceGraph } from "../src/provenance_graph.js";
import { createAuditLedger } from "../src/ledger.js";
import { createCircuitBreaker } from "../src/circuit_breaker.js";

test("strategy registry supports custom strategy", () => {
  const reg = createStrategyRegistry();
  reg.register({
    id: "custom-host",
    host: "example.com",
    decode: () => "https://cdn.example.com/x.mp4",
    confidence: 0.9
  });
  const out = reg.apply({
    host: "example.com",
    url: "https://example.com/a",
    urlObj: new URL("https://example.com/a")
  });
  assert.equal(out.strategyId, "custom-host");
});

test("anomaly detector flags high defer rate", () => {
  const events = [
    { type: "deferred" }, { type: "deferred" }, { type: "deferred" },
    { type: "deferred" }, { type: "decoded" }, { type: "deferred" }
  ];
  const out = detectAnomalies(events);
  assert.equal(out.ok, false);
  assert.equal(out.findings.length > 0, true);
});

test("provenance graph builds nodes and edges", () => {
  const graph = buildProvenanceGraph([
    { original: "a", decoded: "b", confidence: 0.8, provenance: { strategyId: "s1" } }
  ]);
  assert.equal(graph.nodes.length >= 2, true);
  assert.equal(graph.edges.length, 1);
});

test("audit ledger chains hashes", async () => {
  const ledger = createAuditLedger();
  const a = await ledger.append({ type: "x" }, globalThis.crypto);
  const b = await ledger.append({ type: "y" }, globalThis.crypto);
  assert.equal(a.hash.length, 64);
  assert.equal(b.prevHash, a.hash);
});

test("circuit breaker opens at threshold", () => {
  const cb = createCircuitBreaker();
  cb.recordFailure("emload.com");
  cb.recordFailure("emload.com");
  cb.evaluate("emload.com", 2);
  assert.equal(cb.isOpen("emload.com"), true);
});
