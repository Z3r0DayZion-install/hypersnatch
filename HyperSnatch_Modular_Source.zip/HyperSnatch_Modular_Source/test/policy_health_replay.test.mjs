import test from "node:test";
import assert from "node:assert/strict";
import { canUseNetwork, createPolicyState, setReleaseChannel } from "../src/policy.js";
import { runHealthChecks } from "../src/health.js";
import { createReplayStore } from "../src/replay.js";
import { createQuarantineStore, shouldQuarantine } from "../src/quarantine.js";

test("policy channel mutation and network policy", () => {
  const policy = createPolicyState();
  setReleaseChannel(policy, "canary");
  assert.equal(policy.maxConcurrency, 4);
  assert.equal(canUseNetwork(policy), true);
  policy.airgapped = true;
  assert.equal(canUseNetwork(policy), false);
});

test("health checks report valid engine state", () => {
  const report = runHealthChecks({
    state: { tier: "basic", queue: [], decoded: [], deferred: [] }
  });
  assert.equal(report.ok, true);
  assert.equal(report.checks.length >= 3, true);
});

test("replay store keeps ordered events", () => {
  const replay = createReplayStore(3);
  replay.push({ type: "a" });
  replay.push({ type: "b" });
  assert.equal(replay.all().length, 2);
  assert.equal(replay.filterByType("b").length, 1);
});

test("quarantine rules flag dangerous urls", () => {
  const q = createQuarantineStore();
  const check = shouldQuarantine("javascript:alert(1)", "Malformed URL");
  assert.equal(check.yes, true);
  q.add("javascript:alert(1)", check.reason, check.severity);
  assert.equal(q.all().length, 1);
});
