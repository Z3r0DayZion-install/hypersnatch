import test from "node:test";
import assert from "node:assert/strict";
import {
  buildReleaseManifest,
  canonicalManifestText,
  signReleaseManifest,
  verifyReleaseManifest
} from "../src/release.js";
import { generateSigningKeyPair } from "../src/signing.js";

test("buildReleaseManifest computes hashes", async () => {
  const manifest = await buildReleaseManifest([
    { path: "a.txt", content: "alpha" },
    { path: "b.txt", content: "beta" }
  ], globalThis.crypto);
  assert.equal(manifest.format, "hs-release-manifest-v1");
  assert.equal(manifest.items.length, 2);
  assert.ok(manifest.items[0].sha256.length === 64);
});

test("sign and verify release manifest", async () => {
  const manifest = await buildReleaseManifest([{ path: "x", content: "1" }], globalThis.crypto);
  const keys = await generateSigningKeyPair(globalThis.crypto);
  const signed = await signReleaseManifest(manifest, keys.privateKey, "rel", globalThis.crypto);
  const ok = await verifyReleaseManifest(signed, keys.publicKey, globalThis.crypto);
  assert.equal(ok, true);
});

test("manifest verify fails after tamper", async () => {
  const manifest = await buildReleaseManifest([{ path: "x", content: "1" }], globalThis.crypto);
  const keys = await generateSigningKeyPair(globalThis.crypto);
  const signed = await signReleaseManifest(manifest, keys.privateKey, "rel", globalThis.crypto);
  const before = canonicalManifestText(signed);
  signed.items[0].bytes = 999;
  const after = canonicalManifestText(signed);
  assert.notEqual(before, after);
  const ok = await verifyReleaseManifest(signed, keys.publicKey, globalThis.crypto);
  assert.equal(ok, false);
});
