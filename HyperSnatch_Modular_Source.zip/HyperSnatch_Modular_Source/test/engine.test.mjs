import test from "node:test";
import assert from "node:assert/strict";
import { createEngine } from "../src/engine.js";

test("engine processes decode queue and defers gated host", () => {
  const engine = createEngine({ tier: "basic" });
  engine.enqueue("https://emload.com/file/a https://kshared.com/file/b");
  const result = engine.runQueue(1000);
  assert.equal(result.decodedCount, 1);
  assert.equal(result.deferredCount, 1);
  assert.equal(engine.state.decoded.length, 1);
  assert.equal(engine.state.deferred.length, 1);
});

test("engine retryReady moves deferred after delay", () => {
  const engine = createEngine({ tier: "basic" });
  engine.enqueue("https://kshared.com/file/b");
  engine.runQueue(1000);
  const movedEarly = engine.retryReady(2000);
  assert.equal(movedEarly, 0);
  const movedLate = engine.retryReady(7000);
  assert.equal(movedLate, 1);
});
