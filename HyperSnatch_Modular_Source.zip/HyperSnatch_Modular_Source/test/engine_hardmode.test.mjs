import test from "node:test";
import assert from "node:assert/strict";
import { createEngine } from "../src/engine.js";

test("runQueueConcurrent decodes local path with provenance/confidence", async () => {
  const engine = createEngine({ tier: "basic" });
  engine.enqueue("https://emload.com/file/a1");
  const out = await engine.runQueueConcurrent(1000, { concurrency: 2 });
  assert.equal(out.decodedCount, 1);
  assert.equal(engine.state.decoded.length, 1);
  assert.equal(typeof engine.state.decoded[0].confidence, "number");
  assert.equal(typeof engine.state.decoded[0].provenance.strategyId, "string");
});

test("runQueueConcurrent quarantines malformed URL", async () => {
  const engine = createEngine({ tier: "basic" });
  engine.state.queue.push("javascript:alert(1)");
  const out = await engine.runQueueConcurrent(1000, { concurrency: 1 });
  assert.equal(out.deferredCount, 1);
  assert.equal(engine.getQuarantine().length, 1);
});

test("airgapped policy blocks adapter path", async () => {
  const engine = createEngine({ tier: "basic" });
  engine.setAirgapped(true);
  engine.enqueue("https://emload.com/file/");
  const fakeFetch = async () => ({ ok: true, text: async () => '<video src="https://cdn.x/a.mp4"></video>' });
  const out = await engine.runQueueConcurrent(1000, {
    concurrency: 1,
    enableOnlineAdapter: true,
    fetchImpl: fakeFetch
  });
  assert.equal(out.deferredCount, 1);
});

test("release channel sets concurrency policy", () => {
  const engine = createEngine({ tier: "basic" });
  engine.setReleaseChannel("nightly");
  assert.equal(engine.policy.maxConcurrency, 6);
});

test("policy profile strict enforces high confidence and defers", async () => {
  const engine = createEngine({ tier: "basic" });
  engine.setProfile("strict");
  engine.enqueue("https://rapidgator.net/file/abc123ef");
  const out = await engine.runQueueConcurrent(1000, { concurrency: 1 });
  assert.equal(out.deferredCount, 1);
});

test("engine emits replay, provenance, anomalies, and ledger", async () => {
  const engine = createEngine({ tier: "basic" });
  engine.enqueue("https://emload.com/file/a");
  await engine.runQueueConcurrent(1000, { concurrency: 1 });
  assert.equal(engine.getReplay().length > 0, true);
  const graph = engine.getProvenanceGraph();
  assert.equal(graph.nodes.length > 0, true);
  const ledger = engine.getLedger();
  assert.equal(ledger.length > 0, true);
  const anomalies = engine.getAnomalies();
  assert.equal(typeof anomalies.ok, "boolean");
});
