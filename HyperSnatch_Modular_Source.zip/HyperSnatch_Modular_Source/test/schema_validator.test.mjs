import test from "node:test";
import assert from "node:assert/strict";
import { 
  validateSchema, 
  validateWithErrors, 
  getSchemaType,
  SchemaType,
  validateTearV2Pack,
  validateTearBundle,
  validateReleaseManifest,
  validateTrustStore,
  validateQuarantine,
  validateDoctorReport,
  ValidationError
} from "../src/schema_validator.js";

test("validateTearV2Pack validates correct pack", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "1.4.0",
    kind: "tear",
    createdAt: "2026-02-18T00:00:00.000Z",
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDREVGRUZfS0VZXzEyMw==",
    iv: "QUJDREVGRUZfS0VZXzEyMw==",
    digest: "QUJDREVGRUZfS0VZXzEyMw==",
    data: "QUJDREVGRUZfS0VZXzEyMw=="
  };
  assert.equal(validateTearV2Pack(pack), true);
});

test("validateTearV2Pack rejects wrong format", () => {
  const pack = {
    format: "tear-v1",
    schemaVersion: 2
  };
  assert.throws(() => validateTearV2Pack(pack), ValidationError);
});

test("validateTearV2Pack rejects missing required fields", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2
  };
  assert.throws(() => validateTearV2Pack(pack), ValidationError);
});

test("validateTearBundle validates correct bundle", () => {
  const bundle = {
    schema: "hs-tear-bundle-1",
    schemaVersion: 1,
    app: "HyperSnatch",
    appVersion: "1.4.0",
    createdAt: "2026-02-18T00:00:00.000Z",
    deterministic: true,
    manifest: {
      format: "hs-bundle-manifest-v1",
      entries: [
        { path: "a.txt", type: "text", size: 100, sha256: "a".repeat(64) }
      ]
    }
  };
  assert.equal(validateTearBundle(bundle), true);
});

test("validateReleaseManifest validates correct manifest", () => {
  const manifest = {
    format: "hs-release-manifest-v1",
    createdAt: "2026-02-18T00:00:00.000Z",
    items: [
      { path: "file.txt", bytes: 100, sha256: "a".repeat(64) }
    ]
  };
  assert.equal(validateReleaseManifest(manifest), true);
});

test("validateTrustStore validates correct trust store", () => {
  const store = {
    format: "hs-trust-store-v1",
    schemaVersion: 1,
    keys: [
      { id: "k1", label: "Test Key", publicJwk: {}, revoked: false }
    ]
  };
  assert.equal(validateTrustStore(store), true);
});

test("validateQuarantine validates correct quarantine", () => {
  const q = {
    format: "hs-quarantine-v1",
    schemaVersion: 1,
    entries: [
      { id: "q1", reason: "test", timestamp: "2026-02-18T00:00:00.000Z" }
    ]
  };
  assert.equal(validateQuarantine(q), true);
});

test("validateDoctorReport validates correct report", () => {
  const report = {
    format: "hs-doctor-report-v1",
    schemaVersion: 1,
    createdAt: "2026-02-18T00:00:00.000Z",
    app: "HyperSnatch",
    appVersion: "1.4.0",
    checks: [
      { name: "test", status: "pass" }
    ]
  };
  assert.equal(validateDoctorReport(report), true);
});

test("validateWithErrors returns valid for good pack", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "1.4.0",
    kind: "tear",
    createdAt: "2026-02-18T00:00:00.000Z",
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA=="
  };
  const result = validateWithErrors(pack);
  assert.equal(result.valid, true);
  assert.equal(result.errors.length, 0);
});

test("validateWithErrors returns errors for bad pack", () => {
  const pack = {
    format: "tear-v2"
  };
  const result = validateWithErrors(pack);
  assert.equal(result.valid, false);
  assert.ok(result.errors.length > 0);
});

test("getSchemaType returns format for pack", () => {
  const pack = { format: "tear-v2" };
  assert.equal(getSchemaType(pack), "tear-v2");
});

test("getSchemaType returns schema for bundle", () => {
  const bundle = { schema: "hs-tear-bundle-1" };
  assert.equal(getSchemaType(bundle), "hs-tear-bundle-1");
});

test("getSchemaType returns null for unknown", () => {
  assert.equal(getSchemaType({}), null);
});

test("validateSchema dispatches to correct validator", () => {
  const pack = {
    format: "tear-v2",
    schemaVersion: 2,
    app: "HyperSnatch",
    appVersion: "1.4.0",
    kind: "tear",
    createdAt: "2026-02-18T00:00:00.000Z",
    kdf: "PBKDF2-SHA256",
    iterations: 120000,
    salt: "QUJDRA==",
    iv: "QUJDRA==",
    digest: "QUJDRA==",
    data: "QUJDRA=="
  };
  assert.equal(validateSchema(pack), true);
});
